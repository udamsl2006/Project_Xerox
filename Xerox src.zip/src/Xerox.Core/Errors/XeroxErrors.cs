namespace Xerox.Core.Errors;

// ── Base error ────────────────────────────────────────────────────────────────

/// <summary>Base class for all Xerox language errors.</summary>
public abstract class XeroxError
{
    public string Message { get; }
    public int    Line    { get; }
    public int    Column  { get; }
    public string File    { get; }

    protected XeroxError(string message, int line, int column, string file)
    {
        Message = message;
        Line    = line;
        Column  = column;
        File    = file;
    }

    public override string ToString() =>
        $"[{Phase}] {File}:{Line}:{Column} — {Message}";

    protected abstract string Phase { get; }

    public string FormatFull(string[] sourceLines)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine(ToString());
        if (Line >= 1 && Line <= sourceLines.Length)
        {
            string srcLine = sourceLines[Line - 1];
            sb.AppendLine($"  {Line,4} │ {srcLine}");
            string caret = new string(' ', Column + 7) + "^";
            sb.AppendLine(caret);
        }
        return sb.ToString();
    }
}

// ── Lexer errors ──────────────────────────────────────────────────────────────

public sealed class LexerError : XeroxError
{
    protected override string Phase => "Lexer";
    public LexerError(string message, int line, int column, string file = "<input>")
        : base(message, line, column, file) { }
}

// ── Parser errors ─────────────────────────────────────────────────────────────

public sealed class ParseError : XeroxError
{
    protected override string Phase => "Parser";
    public ParseError(string message, int line, int column, string file = "<input>")
        : base(message, line, column, file) { }
}

// ── Semantic errors ───────────────────────────────────────────────────────────

public sealed class SemanticError : XeroxError
{
    protected override string Phase => "Semantic";
    public SemanticError(string message, int line, int column, string file = "<input>")
        : base(message, line, column, file) { }
}

// ── Runtime errors ────────────────────────────────────────────────────────────

public sealed class RuntimeError : XeroxError
{
    protected override string Phase => "Runtime";
    public RuntimeError(string message, int line, int column, string file = "<input>")
        : base(message, line, column, file) { }
}

// ── Exceptions that carry Xerox errors ───────────────────────────────────────

public class XeroxException : Exception
{
    public IReadOnlyList<XeroxError> Errors { get; }

    public XeroxException(IReadOnlyList<XeroxError> errors)
        : base(FormatMessage(errors))
    {
        Errors = errors;
    }

    public XeroxException(XeroxError single)
        : this(new[] { single }) { }

    private static string FormatMessage(IReadOnlyList<XeroxError> errors) =>
        string.Join(Environment.NewLine, errors.Select(e => e.ToString()));
}

public sealed class LexerException    : XeroxException
{
    public LexerException(IReadOnlyList<XeroxError> errors) : base(errors) { }
}

public sealed class ParseException    : XeroxException
{
    public ParseException(IReadOnlyList<XeroxError> errors) : base(errors) { }
    public ParseException(XeroxError single) : base(single) { }
}

public sealed class SemanticException : XeroxException
{
    public SemanticException(IReadOnlyList<XeroxError> errors) : base(errors) { }
}

/// <summary>
/// Thrown internally to unwind the call stack during runtime signal propagation.
/// Not a user-visible error.
/// </summary>
public sealed class ReturnSignal : Exception
{
    public object? Value { get; }
    public ReturnSignal(object? value) : base("return") { Value = value; }
}

public sealed class BreakSignal    : Exception { public BreakSignal()    : base("break") { } }
public sealed class ContinueSignal : Exception { public ContinueSignal() : base("continue") { } }

/// <summary>Thrown for runtime errors with a token reference.</summary>
public sealed class XeroxRuntimeException : Exception
{
    public RuntimeError Error { get; }
    public XeroxRuntimeException(RuntimeError error) : base(error.ToString()) { Error = error; }
    public XeroxRuntimeException(string message, int line, int col, string file = "<input>")
        : this(new RuntimeError(message, line, col, file)) { }
}