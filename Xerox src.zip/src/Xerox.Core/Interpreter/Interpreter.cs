using Xerox.Core.Errors;
using Xerox.Core.Parsing.AST;

namespace Xerox.Core.Interpreter;

/// <summary>
/// Tree-walk interpreter for Xerox.
/// Visits each AST node and evaluates it directly against a runtime environment.
/// </summary>
public sealed class Interpreter
{
    // ── Configuration ─────────────────────────────────────────────────────────

    public TextWriter  Output   { get; set; } = Console.Out;
    public TextReader  Input    { get; set; } = Console.In;
    public bool        Verbose  { get; set; } = false;

    // ── Global environment ────────────────────────────────────────────────────

    public XeEnvironment Globals { get; } = new();

    public Interpreter()
    {
        StdLib.StandardLibrary.Register(Globals);
    }

    // ── Public run API ────────────────────────────────────────────────────────

    /// <summary>Execute a fully parsed program.</summary>
    public void Run(ProgramNode program)
    {
        try
        {
            ExecBlock(new BlockStmt
            {
                Statements = program.Statements,
                SourceToken = program.SourceToken
            }, Globals);
        }
        catch (XeroxRuntimeException) { throw; }
        catch (ReturnSignal)  { /* top-level return is silently ignored */ }
        catch (BreakSignal)   { throw new XeroxRuntimeException("'break' used outside a loop.", 0, 0); }
        catch (ContinueSignal){ throw new XeroxRuntimeException("'continue'/'skip' used outside a loop.", 0, 0); }
    }

    // ── Block execution ───────────────────────────────────────────────────────

    public void ExecBlock(BlockStmt block, XeEnvironment env)
    {
        foreach (var stmt in block.Statements)
            ExecStmt(stmt, env);
    }

    // ── Statement execution ───────────────────────────────────────────────────

    private void ExecStmt(Statement stmt, XeEnvironment env)
    {
        switch (stmt)
        {
            case VarDeclStmt   vd: ExecVarDecl(vd, env);          break;
            case AssignStmt    a:  ExecAssign(a, env);             break;
            case DisplayStmt   d:  ExecDisplay(d, env);            break;
            case ReturnStmt    r:  ExecReturn(r, env);             break;
            case BreakStmt     _:  throw new BreakSignal();
            case ContinueStmt  _:  throw new ContinueSignal();
            case IfStmt        i:  ExecIf(i, env);                 break;
            case WhileStmt     w:  ExecWhile(w, env);              break;
            case RepeatStmt    rp: ExecRepeat(rp, env);            break;
            case ForEachStmt   fe: ExecForEach(fe, env);           break;
            case FunctionDeclStmt fd: ExecFuncDecl(fd, env);       break;
            case BlueprintDeclStmt bp: ExecBlueprintDecl(bp, env); break;
            case ListAddStmt   la: ExecListAdd(la, env);           break;
            case ListRemoveStmt lr: ExecListRemove(lr, env);       break;
            case ExpressionStmt es: EvalExpr(es.Expr, env);        break;
            case BlockStmt     b:
                var child = env.CreateChild();
                ExecBlock(b, child);
                break;
            default:
                throw new XeroxRuntimeException($"Unknown statement type: {stmt.GetType().Name}",
                    stmt.SourceToken.Line, stmt.SourceToken.Column, stmt.SourceToken.File);
        }
    }

    private void ExecVarDecl(VarDeclStmt vd, XeEnvironment env)
    {
        var value = vd.Value is not null ? EvalExpr(vd.Value, env) : XeValue.Nothing;
        env.Define(vd.Name, value);
    }

    private void ExecAssign(AssignStmt a, XeEnvironment env)
    {
        var value = EvalExpr(a.Value, env);
        AssignTarget(a.Target, value, env);
    }

    private void AssignTarget(Expression target, XeValue value, XeEnvironment env)
    {
        switch (target)
        {
            case VariableExpr ve:
                env.Assign(ve.Name, value);
                break;

            case MemberAccessExpr ma:
                var obj = EvalExpr(ma.Object, env);
                if (obj.Kind != ValueKind.Object)
                    RuntimeError(ma.SourceToken, "Can only assign member on an object.");
                obj.AsObject().SetMember(ma.Member, value);
                break;

            case IndexExpr ix:
                var coll = EvalExpr(ix.Collection, env);
                var idx  = EvalExpr(ix.IndexValue, env);
                if (coll.Kind == ValueKind.List)
                {
                    int i = (int)idx.AsNumber();
                    var lst = coll.AsList();
                    if (i < 0 || i >= lst.Count)
                        RuntimeError(ix.SourceToken, $"List index {i} out of bounds (size {lst.Count}).");
                    lst[i] = value;
                }
                else RuntimeError(ix.SourceToken, "Index assignment requires a list.");
                break;

            default:
                RuntimeError(target.SourceToken, "Invalid assignment target.");
                break;
        }
    }

    private void ExecDisplay(DisplayStmt d, XeEnvironment env)
    {
        var parts = d.Values.Select(v => EvalExpr(v, env).ToDisplayString());
        Output.WriteLine(string.Join(" ", parts));
    }

    private void ExecReturn(ReturnStmt r, XeEnvironment env)
    {
        var value = r.Value is not null ? EvalExpr(r.Value, env) : XeValue.Nothing;
        throw new ReturnSignal(value);
    }

    private void ExecIf(IfStmt i, XeEnvironment env)
    {
        if (EvalExpr(i.Condition, env).IsTruthy)
        {
            ExecBlock(i.ThenBranch, env.CreateChild());
            return;
        }
        foreach (var (cond, body) in i.ElseIfs)
        {
            if (EvalExpr(cond, env).IsTruthy)
            {
                ExecBlock(body, env.CreateChild());
                return;
            }
        }
        if (i.ElseBranch is not null)
            ExecBlock(i.ElseBranch, env.CreateChild());
    }

    private void ExecWhile(WhileStmt w, XeEnvironment env)
    {
        while (EvalExpr(w.Condition, env).IsTruthy)
        {
            try   { ExecBlock(w.Body, env.CreateChild()); }
            catch (BreakSignal)    { break; }
            catch (ContinueSignal) { continue; }
        }
    }

    private void ExecRepeat(RepeatStmt rp, XeEnvironment env)
    {
        double count = EvalExpr(rp.Count, env).AsNumber();
        for (long i = 0; i < (long)count; i++)
        {
            try   { ExecBlock(rp.Body, env.CreateChild()); }
            catch (BreakSignal)    { break; }
            catch (ContinueSignal) { continue; }
        }
    }

    private void ExecForEach(ForEachStmt fe, XeEnvironment env)
    {
        var coll = EvalExpr(fe.Collection, env);
        IEnumerable<XeValue> items;
        if (coll.Kind == ValueKind.List)
            items = coll.AsList();
        else if (coll.Kind == ValueKind.Text)
            items = coll.AsString().Select(c => XeValue.FromString(c.ToString()));
        else
        {
            RuntimeError(fe.SourceToken, "Expected a list or text to iterate over.");
            return; // unreachable, but satisfies definite assignment
        }

        foreach (var item in items)
        {
            var loopEnv = env.CreateChild();
            loopEnv.Define(fe.Variable, item);
            try   { ExecBlock(fe.Body, loopEnv); }
            catch (BreakSignal)    { break; }
            catch (ContinueSignal) { continue; }
        }
    }

    private void ExecFuncDecl(FunctionDeclStmt fd, XeEnvironment env)
    {
        var fn = new XeFunction(fd, env);
        env.Define(fd.Name, XeValue.FromCallable(fn));
    }

    private void ExecBlueprintDecl(BlueprintDeclStmt bp, XeEnvironment env)
    {
        // Resolve parent blueprint
        XeBlueprint? parent = null;
        if (bp.Parent is not null)
        {
            if (!env.TryGet(bp.Parent, out var parentVal) || parentVal.Kind != ValueKind.Callable)
                RuntimeError(bp.SourceToken, $"Blueprint '{bp.Parent}' not found.");
            if (parentVal.AsCallable() is XeConstructor xc)
                parent = xc.Blueprint;
            else
                RuntimeError(bp.SourceToken, $"'{bp.Parent}' is not a blueprint.");
        }

        var blueprint = new XeBlueprint(bp.Name, parent);

        // Register fields with defaults
        foreach (var field in bp.Fields)
        {
            var defaultVal = field.Default is not null
                ? EvalExpr(field.Default, env)
                : XeValue.Nothing;
            blueprint.AddField(field.Name, defaultVal);
        }

        // Register methods
        foreach (var method in bp.Methods)
        {
            var fn = new XeFunction(method, env);
            blueprint.AddMethod(method.Name, fn);
        }

        // Build constructor
        var ctor = new XeConstructor(blueprint, bp.Constructor, env);

        env.Define(bp.Name, XeValue.FromCallable(ctor));

        if (Verbose)
            Output.WriteLine($"[Xerox] Blueprint '{bp.Name}' registered.");
    }

    private void ExecListAdd(ListAddStmt la, XeEnvironment env)
    {
        var value = EvalExpr(la.Value, env);
        var list  = EvalExpr(la.List, env);
        if (list.Kind != ValueKind.List)
            RuntimeError(la.SourceToken, "Expected a list for 'add … to …'.");
        list.AsList().Add(value);
    }

    private void ExecListRemove(ListRemoveStmt lr, XeEnvironment env)
    {
        var list = EvalExpr(lr.List, env);
        if (list.Kind != ValueKind.List)
            RuntimeError(lr.SourceToken, "Expected a list for 'remove'.");
        var lst = list.AsList();

        if (lr.AtIndex is not null)
        {
            int i = (int)EvalExpr(lr.AtIndex, env).AsNumber();
            if (i < 0 || i >= lst.Count)
                RuntimeError(lr.SourceToken, $"Remove index {i} out of bounds.");
            lst.RemoveAt(i);
        }
        else if (lr.Value is not null)
        {
            var target = EvalExpr(lr.Value, env);
            var idx = lst.FindIndex(v => v.XeEquals(target));
            if (idx >= 0) lst.RemoveAt(idx);
        }
    }

    // ── Expression evaluation ─────────────────────────────────────────────────

    public XeValue EvalExpr(Expression expr, XeEnvironment env) => expr switch
    {
        LiteralExpr    l => EvalLiteral(l),
        VariableExpr   v => EvalVariable(v, env),
        SelfExpr       _ => env.Get("itself"),
        BinaryExpr     b => EvalBinary(b, env),
        UnaryExpr      u => EvalUnary(u, env),
        CallExpr       c => EvalCall(c, env),
        MemberAccessExpr m => EvalMemberAccess(m, env),
        IndexExpr      i => EvalIndex(i, env),
        NewObjectExpr  n => EvalNewObject(n, env),
        ListLiteralExpr ll => EvalListLiteral(ll, env),
        LengthExpr     le => EvalLength(le, env),
        CountExpr      ce => EvalCount(ce, env),
        BuiltinMathExpr bm => EvalBuiltinMath(bm, env),
        BuiltinMath2Expr bm2 => EvalBuiltinMath2(bm2, env),
        AskExpr        a => EvalAsk(a, env),
        AssignExpr     ae => EvalAssignExpr(ae, env),
        _ => throw new XeroxRuntimeException($"Unknown expression type: {expr.GetType().Name}",
                 expr.SourceToken.Line, expr.SourceToken.Column, expr.SourceToken.File)
    };

    private static XeValue EvalLiteral(LiteralExpr l) => l.Value switch
    {
        null   => XeValue.Nothing,
        bool b => XeValue.FromBool(b),
        double d => XeValue.FromDouble(d),
        string s => XeValue.FromString(s),
        _ => XeValue.Nothing
    };

    private XeValue EvalVariable(VariableExpr v, XeEnvironment env)
    {
        if (!env.TryGet(v.Name, out var val))
            RuntimeError(v.SourceToken, $"Undefined variable '{v.Name}'.");
        return val;
    }

    private XeValue EvalBinary(BinaryExpr b, XeEnvironment env)
    {
        // Short-circuit logical operators
        if (b.Operator == BinaryOp.And)
        {
            var left = EvalExpr(b.Left, env);
            return left.IsTruthy ? EvalExpr(b.Right, env) : XeValue.False;
        }
        if (b.Operator == BinaryOp.Or)
        {
            var left = EvalExpr(b.Left, env);
            return left.IsTruthy ? left : EvalExpr(b.Right, env);
        }

        var l = EvalExpr(b.Left,  env);
        var r = EvalExpr(b.Right, env);

        return b.Operator switch
        {
            BinaryOp.Add =>
                (l.Kind == ValueKind.Text || r.Kind == ValueKind.Text)
                    ? XeValue.FromString(l.ToDisplayString() + r.ToDisplayString())
                    : XeValue.FromDouble(l.AsNumber() + r.AsNumber()),

            BinaryOp.Subtract  => XeValue.FromDouble(l.AsNumber() - r.AsNumber()),
            BinaryOp.Multiply  => XeValue.FromDouble(l.AsNumber() * r.AsNumber()),
            BinaryOp.Divide    => r.AsNumber() == 0
                                    ? RuntimeError<XeValue>(b.SourceToken, "Division by zero.")
                                    : XeValue.FromDouble(l.AsNumber() / r.AsNumber()),
            BinaryOp.Modulo    => r.AsNumber() == 0
                                    ? RuntimeError<XeValue>(b.SourceToken, "Modulo by zero.")
                                    : XeValue.FromDouble(l.AsNumber() % r.AsNumber()),

            BinaryOp.Equal          => XeValue.FromBool(l.XeEquals(r)),
            BinaryOp.NotEqual       => XeValue.FromBool(!l.XeEquals(r)),
            BinaryOp.Less           => XeValue.FromBool(CompareValues(l, r, b.SourceToken) < 0),
            BinaryOp.LessOrEqual    => XeValue.FromBool(CompareValues(l, r, b.SourceToken) <= 0),
            BinaryOp.Greater        => XeValue.FromBool(CompareValues(l, r, b.SourceToken) > 0),
            BinaryOp.GreaterOrEqual => XeValue.FromBool(CompareValues(l, r, b.SourceToken) >= 0),

            BinaryOp.Concat     => XeValue.FromString(l.ToDisplayString() + r.ToDisplayString()),
            BinaryOp.Contains   => l.Kind == ValueKind.List
                ? XeValue.FromBool(l.AsList().Any(v => v.XeEquals(r)))
                : XeValue.FromBool(l.AsString().Contains(r.AsString())),
            BinaryOp.StartsWith => XeValue.FromBool(l.AsString().StartsWith(r.AsString())),
            BinaryOp.EndsWith   => XeValue.FromBool(l.AsString().EndsWith(r.AsString())),

            _ => RuntimeError<XeValue>(b.SourceToken, $"Unknown binary operator {b.Operator}.")
        };
    }

    private int CompareValues(XeValue l, XeValue r, Lexing.Token tok)
    {
        if (l.Kind == ValueKind.Number && r.Kind == ValueKind.Number)
            return l.AsNumber().CompareTo(r.AsNumber());
        if (l.Kind == ValueKind.Text && r.Kind == ValueKind.Text)
            return string.Compare(l.AsString(), r.AsString(), StringComparison.Ordinal);
        RuntimeError(tok, $"Cannot compare {l.Kind} with {r.Kind}.");
        return 0;
    }

    private XeValue EvalUnary(UnaryExpr u, XeEnvironment env)
    {
        var operand = EvalExpr(u.Operand, env);
        return u.Operator switch
        {
            UnaryOp.Negate => XeValue.FromDouble(-operand.AsNumber()),
            UnaryOp.Not    => XeValue.FromBool(!operand.IsTruthy),
            _ => RuntimeError<XeValue>(u.SourceToken, $"Unknown unary operator {u.Operator}.")
        };
    }

    private XeValue EvalCall(CallExpr c, XeEnvironment env)
    {
        var callee = EvalExpr(c.Callee, env);
        if (callee.Kind != ValueKind.Callable)
        {
            RuntimeError(c.SourceToken,
                $"'{(c.Callee is VariableExpr ve ? ve.Name : "expression")}' is not callable.");
        }
        var fn   = callee.AsCallable();
        var args = c.Args.Select(a => EvalExpr(a, env)).ToList();

        try
        {
            return fn.Call(this, args);
        }
        catch (XeroxRuntimeException) { throw; }
        catch (ReturnSignal sig)       { return sig.Value == null ? XeValue.Nothing : (XeValue)sig.Value; }
        catch (Exception ex)
        {
            RuntimeError(c.SourceToken, $"Error calling '{fn.Name}': {ex.Message}");
            return XeValue.Nothing;
        }
    }

    private XeValue EvalMemberAccess(MemberAccessExpr m, XeEnvironment env)
    {
        var obj = EvalExpr(m.Object, env);

        // Object instance member access
        if (obj.Kind == ValueKind.Object)
        {
            var instance = obj.AsObject();
            // 1. Try fields
            if (instance.TryGetMember(m.Member, out var fieldVal)) return fieldVal;
            // 2. Try methods (return as bound callable)
            if (instance.Blueprint.TryGetMethod(m.Member, out var method))
            {
                if (method is XeFunction xf)
                    return XeValue.FromCallable(new XeMethod(xf, instance));
                return XeValue.FromCallable(method);
            }
            RuntimeError(m.SourceToken, $"Object '{instance.BlueprintName}' has no member '{m.Member}'.");
        }

        // Text built-ins via dot syntax: myText.upper()
        if (obj.Kind == ValueKind.Text)
        {
            return m.Member.ToLowerInvariant() switch
            {
                "length"  => XeValue.FromDouble(obj.AsString().Length),
                "upper"   => XeValue.FromString(obj.AsString().ToUpperInvariant()),
                "lower"   => XeValue.FromString(obj.AsString().ToLowerInvariant()),
                "trim"    => XeValue.FromString(obj.AsString().Trim()),
                "reverse" => XeValue.FromString(new string(obj.AsString().Reverse().ToArray())),
                _ => MakeStringMethod(obj, m.Member, m.SourceToken)
            };
        }

        // List built-ins via dot syntax: myList.count
        if (obj.Kind == ValueKind.List)
        {
            // BUG FIX: "isEmpty" was used as a switch case but member names are
            // compared after ToLowerInvariant(), so "isEmpty" never matched.
            // Changed to lowercase "isempty" to match correctly.
            return m.Member.ToLowerInvariant() switch
            {
                "count"   => XeValue.FromDouble(obj.AsList().Count),
                "length"  => XeValue.FromDouble(obj.AsList().Count),
                "isempty" => XeValue.FromBool(obj.AsList().Count == 0),   // was "isEmpty" — never matched
                "first"   => obj.AsList().Count > 0 ? obj.AsList()[0] : XeValue.Nothing,
                "last"    => obj.AsList().Count > 0 ? obj.AsList()[^1] : XeValue.Nothing,
                _ => MakeListMethod(obj, m.Member, m.SourceToken)
            };
        }

        RuntimeError(m.SourceToken, $"Cannot access member '{m.Member}' on a {obj.Kind}.");
        return XeValue.Nothing;
    }

    private XeValue MakeStringMethod(XeValue str, string name, Lexing.Token tok) =>
        name.ToLowerInvariant() switch
        {
            "split"      => XeValue.FromCallable(new NativeFunction("split", 1, (_, a) =>
                             XeValue.FromList(str.AsString().Split(a[0].AsString()).Select(XeValue.FromString).ToList()))),
            "contains"   => XeValue.FromCallable(new NativeFunction("contains", 1, (_, a) =>
                             XeValue.FromBool(str.AsString().Contains(a[0].AsString())))),
            "startswith" => XeValue.FromCallable(new NativeFunction("startsWith", 1, (_, a) =>
                             XeValue.FromBool(str.AsString().StartsWith(a[0].AsString())))),
            "endswith"   => XeValue.FromCallable(new NativeFunction("endsWith", 1, (_, a) =>
                             XeValue.FromBool(str.AsString().EndsWith(a[0].AsString())))),
            "replace"    => XeValue.FromCallable(new NativeFunction("replace", 2, (_, a) =>
                             XeValue.FromString(str.AsString().Replace(a[0].AsString(), a[1].AsString())))),
            "indexof"    => XeValue.FromCallable(new NativeFunction("indexOf", 1, (_, a) =>
                             XeValue.FromDouble(str.AsString().IndexOf(a[0].AsString())))),
            _            => RuntimeError<XeValue>(tok, $"Text has no method '{name}'.")
        };

    private XeValue MakeListMethod(XeValue list, string name, Lexing.Token tok) =>
        name.ToLowerInvariant() switch
        {
            "add"     => XeValue.FromCallable(new NativeFunction("add", 1, (_, a) => { list.AsList().Add(a[0]); return XeValue.Nothing; })),
            "remove"  => XeValue.FromCallable(new NativeFunction("remove", 1, (_, a) => { list.AsList().Remove(a[0]); return XeValue.Nothing; })),
            "contains"=> XeValue.FromCallable(new NativeFunction("contains", 1, (_, a) =>
                          XeValue.FromBool(list.AsList().Any(v => v.XeEquals(a[0]))))),
            "sort"    => XeValue.FromCallable(new NativeFunction("sort", 0, (_, _) => {
                          list.AsList().Sort((x, y) => x.Kind == ValueKind.Number && y.Kind == ValueKind.Number
                              ? x.AsNumber().CompareTo(y.AsNumber())
                              : string.Compare(x.AsString(), y.AsString(), StringComparison.Ordinal));
                          return XeValue.Nothing; })),
            _         => RuntimeError<XeValue>(tok, $"List has no method '{name}'.")
        };

    private XeValue EvalIndex(IndexExpr ix, XeEnvironment env)
    {
        var coll = EvalExpr(ix.Collection, env);
        var idxV = EvalExpr(ix.IndexValue,  env);

        if (coll.Kind == ValueKind.List)
        {
            int i = (int)idxV.AsNumber();
            var lst = coll.AsList();
            if (i < 0 || i >= lst.Count)
                RuntimeError(ix.SourceToken, $"List index {i} out of bounds (size {lst.Count}).");
            return lst[i];
        }
        if (coll.Kind == ValueKind.Text)
        {
            int i = (int)idxV.AsNumber();
            var s = coll.AsString();
            if (i < 0 || i >= s.Length)
                RuntimeError(ix.SourceToken, $"String index {i} out of bounds (length {s.Length}).");
            return XeValue.FromString(s[i].ToString());
        }
        RuntimeError(ix.SourceToken, $"Cannot index into a {coll.Kind}.");
        return XeValue.Nothing;
    }

    private XeValue EvalNewObject(NewObjectExpr n, XeEnvironment env)
    {
        if (!env.TryGet(n.BlueprintName, out var bp))
            RuntimeError(n.SourceToken, $"Blueprint '{n.BlueprintName}' not found.");
        if (bp.Kind != ValueKind.Callable)
            RuntimeError(n.SourceToken, $"'{n.BlueprintName}' is not a blueprint.");
        var args = n.Args.Select(a => EvalExpr(a, env)).ToList();
        return bp.AsCallable().Call(this, args);
    }

    private XeValue EvalListLiteral(ListLiteralExpr ll, XeEnvironment env)
    {
        var items = ll.Items.Select(i => EvalExpr(i, env)).ToList();
        return XeValue.FromList(items);
    }

    private XeValue EvalLength(LengthExpr le, XeEnvironment env)
    {
        var target = EvalExpr(le.Target, env);
        return target.Kind switch
        {
            ValueKind.Text => XeValue.FromDouble(target.AsString().Length),
            ValueKind.List => XeValue.FromDouble(target.AsList().Count),
            _ => RuntimeError<XeValue>(le.SourceToken, $"Cannot get length of {target.Kind}.")
        };
    }

    private XeValue EvalCount(CountExpr ce, XeEnvironment env)
    {
        var coll = EvalExpr(ce.Collection, env);
        return coll.Kind switch
        {
            ValueKind.List => XeValue.FromDouble(coll.AsList().Count),
            ValueKind.Text => XeValue.FromDouble(coll.AsString().Length),
            _ => RuntimeError<XeValue>(ce.SourceToken, $"Cannot count a {coll.Kind}.")
        };
    }

    private static readonly Random _rng = new();

    private XeValue EvalBuiltinMath(BuiltinMathExpr bm, XeEnvironment env)
    {
        var val = EvalExpr(bm.Target, env).AsNumber();
        return bm.Op switch
        {
            BuiltinMathOp.Absolute => XeValue.FromDouble(Math.Abs(val)),
            BuiltinMathOp.Round    => XeValue.FromDouble(Math.Round(val, MidpointRounding.AwayFromZero)),
            BuiltinMathOp.Floor    => XeValue.FromDouble(Math.Floor(val)),
            BuiltinMathOp.Ceiling  => XeValue.FromDouble(Math.Ceiling(val)),
            BuiltinMathOp.Sqrt     => XeValue.FromDouble(Math.Sqrt(val)),
            _ => RuntimeError<XeValue>(bm.SourceToken, $"Unknown math op {bm.Op}.")
        };
    }

    private XeValue EvalBuiltinMath2(BuiltinMath2Expr bm, XeEnvironment env)
    {
        var l = EvalExpr(bm.Left,  env).AsNumber();
        var r = EvalExpr(bm.Right, env).AsNumber();

        if (bm.Op == BuiltinMath2Op.Power)
            return XeValue.FromDouble(Math.Pow(l, r));

        if (bm.Op == BuiltinMath2Op.Random)
        {
            bool isDefault = bm.Left  is LiteralExpr ll && ll.Value is 0.0
                          && bm.Right is LiteralExpr rl && rl.Value is 1.0;
            return isDefault
                ? XeValue.FromDouble(_rng.NextDouble())
                : XeValue.FromDouble(_rng.NextDouble() * (r - l) + l);
        }

        return RuntimeError<XeValue>(bm.SourceToken, $"Unknown math2 op {bm.Op}.");
    }

    private XeValue EvalAssignExpr(AssignExpr ae, XeEnvironment env)
    {
        var value = EvalExpr(ae.Value, env);
        AssignTarget(ae.Target, value, env);
        return value;
    }

    private XeValue EvalAsk(AskExpr a, XeEnvironment env)
    {
        var prompt = EvalExpr(a.Prompt, env).ToDisplayString();
        Output.Write(prompt);
        return XeValue.FromString(Input.ReadLine() ?? "");
    }

    // ── Error helpers ─────────────────────────────────────────────────────────

    private void RuntimeError(Lexing.Token tok, string msg)
    {
        throw new XeroxRuntimeException(msg, tok.Line, tok.Column, tok.File);
    }

    private T RuntimeError<T>(Lexing.Token tok, string msg)
    {
        throw new XeroxRuntimeException(msg, tok.Line, tok.Column, tok.File);
    }
}
