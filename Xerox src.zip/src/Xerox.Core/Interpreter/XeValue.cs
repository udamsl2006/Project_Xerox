namespace Xerox.Core.Interpreter;

/// <summary>
/// Represents every value that exists at runtime in Xerox.
/// Uses a discriminated union-style class to avoid boxing overhead where possible.
/// </summary>
public sealed class XeValue
{
    // ── Canonical singletons ──────────────────────────────────────────────────
    public static readonly XeValue Nothing = new(ValueKind.Nothing, null);
    public static readonly XeValue True    = new(ValueKind.Bool,    true);
    public static readonly XeValue False   = new(ValueKind.Bool,    false);
    public static readonly XeValue Zero    = new(ValueKind.Number,  0.0);
    public static readonly XeValue One     = new(ValueKind.Number,  1.0);

    // ── Fields ────────────────────────────────────────────────────────────────
    public ValueKind Kind  { get; }
    private readonly object? _raw;

    private XeValue(ValueKind kind, object? raw) { Kind = kind; _raw = raw; }

    // ── Factory methods ───────────────────────────────────────────────────────

    public static XeValue FromDouble(double d) =>
        d == 0.0 ? Zero : d == 1.0 ? One : new XeValue(ValueKind.Number, d);

    public static XeValue FromString(string s) => new(ValueKind.Text, s);

    public static XeValue FromBool(bool b) => b ? True : False;

    public static XeValue FromList(List<XeValue> lst) => new(ValueKind.List, lst);

    public static XeValue FromObject(XeObject obj) => new(ValueKind.Object, obj);

    public static XeValue FromCallable(ICallable fn) => new(ValueKind.Callable, fn);

    public static XeValue From(object? raw) => raw switch
    {
        null          => Nothing,
        bool b        => FromBool(b),
        double d      => FromDouble(d),
        int i         => FromDouble(i),
        long l        => FromDouble(l),
        float f       => FromDouble(f),
        string s      => FromString(s),
        List<XeValue> lst => FromList(lst),
        XeObject obj  => FromObject(obj),
        ICallable fn  => FromCallable(fn),
        _             => throw new InvalidOperationException($"Cannot wrap {raw.GetType()} as XeValue")
    };

    // ── Typed accessors ───────────────────────────────────────────────────────

    public double AsNumber()
    {
        if (Kind == ValueKind.Number) return (double)_raw!;
        if (Kind == ValueKind.Bool)   return (bool)_raw! ? 1.0 : 0.0;
        if (Kind == ValueKind.Text && double.TryParse((string)_raw!, out double d)) return d;
        throw new InvalidCastException($"Cannot convert {Kind} to Number.");
    }

    public string AsString() => Kind switch
    {
        ValueKind.Text    => (string)_raw!,
        ValueKind.Number  => FormatNumber((double)_raw!),
        ValueKind.Bool    => (bool)_raw! ? "true" : "false",
        ValueKind.Nothing => "nothing",
        ValueKind.List    => "[" + string.Join(", ", AsList().Select(v => v.ToDisplayString())) + "]",
        ValueKind.Object  => AsObject().ToString()!,
        _                 => _raw?.ToString() ?? "nothing"
    };

    public bool AsBool() => Kind switch
    {
        ValueKind.Bool    => (bool)_raw!,
        ValueKind.Nothing => false,
        ValueKind.Number  => (double)_raw! != 0.0,
        ValueKind.Text    => ((string)_raw!).Length > 0,
        ValueKind.List    => AsList().Count > 0,
        _                 => true
    };

    public List<XeValue> AsList()
    {
        if (Kind == ValueKind.List) return (List<XeValue>)_raw!;
        throw new InvalidCastException($"Expected a List, got {Kind}.");
    }

    public XeObject AsObject()
    {
        if (Kind == ValueKind.Object) return (XeObject)_raw!;
        throw new InvalidCastException($"Expected an Object, got {Kind}.");
    }

    public ICallable AsCallable()
    {
        if (Kind == ValueKind.Callable) return (ICallable)_raw!;
        throw new InvalidCastException($"Expected a Callable, got {Kind}.");
    }

    // ── Truthiness ────────────────────────────────────────────────────────────

    public bool IsNothing => Kind == ValueKind.Nothing;
    public bool IsTruthy  => AsBool();

    // ── Display ───────────────────────────────────────────────────────────────

    public string ToDisplayString() => Kind switch
    {
        ValueKind.Text    => (string)_raw!,
        ValueKind.Number  => FormatNumber((double)_raw!),
        ValueKind.Bool    => (bool)_raw! ? "true" : "false",
        ValueKind.Nothing => "nothing",
        ValueKind.List    => "[" + string.Join(", ", AsList().Select(v => v.ToDisplayString())) + "]",
        ValueKind.Object  => AsObject().ToDisplayString(),
        ValueKind.Callable=> $"<function {((ICallable)_raw!).Name}>",
        _                 => "nothing"
    };

    private static string FormatNumber(double d)
    {
        if (double.IsNaN(d))      return "NaN";
        if (double.IsInfinity(d)) return d > 0 ? "Infinity" : "-Infinity";
        // print integer-valued doubles without decimal point
        if (d == Math.Truncate(d) && Math.Abs(d) < 1e15)
            return ((long)d).ToString();
        return d.ToString("G", System.Globalization.CultureInfo.InvariantCulture);
    }

    // ── Equality ──────────────────────────────────────────────────────────────

    public bool XeEquals(XeValue other)
    {
        if (Kind == ValueKind.Nothing && other.Kind == ValueKind.Nothing) return true;
        if (Kind == ValueKind.Nothing || other.Kind == ValueKind.Nothing) return false;
        if (Kind == ValueKind.Number && other.Kind == ValueKind.Number)   return AsNumber() == other.AsNumber();
        if (Kind == ValueKind.Bool   && other.Kind == ValueKind.Bool)     return AsBool() == other.AsBool();
        if (Kind == ValueKind.Text   && other.Kind == ValueKind.Text)     return AsString() == other.AsString();
        if (Kind == ValueKind.List   && other.Kind == ValueKind.List)
        {
            var a = AsList(); var b = other.AsList();
            if (a.Count != b.Count) return false;
            return a.Zip(b, (x, y) => x.XeEquals(y)).All(eq => eq);
        }
        if (Kind == ValueKind.Object && other.Kind == ValueKind.Object)
            return ReferenceEquals(_raw, other._raw);
        return false;
    }

    public override string ToString() => ToDisplayString();
}

/// <summary>The kind of value a XeValue holds.</summary>
public enum ValueKind
{
    Nothing,
    Number,
    Text,
    Bool,
    List,
    Object,
    Callable
}

/// <summary>Interface for anything callable: functions, methods, native functions.</summary>
public interface ICallable
{
    string Name        { get; }
    int    Arity       { get; }   // -1 = variadic
    XeValue Call(Interpreter interpreter, IReadOnlyList<XeValue> args);
}

/// <summary>A Xerox object instance (created from a blueprint).</summary>
public sealed class XeObject
{
    public string BlueprintName { get; }
    public XeEnvironment Fields { get; } = new();

    public XeBlueprint Blueprint { get; }

    public XeObject(XeBlueprint blueprint)
    {
        Blueprint = blueprint;
        BlueprintName = blueprint.Name;

        // Initialise fields from defaults
        foreach (var field in blueprint.AllFields)
            Fields.Define(field.Key, field.Value);
    }

    public bool TryGetMember(string name, out XeValue value) =>
        Fields.TryGet(name, out value!);

    public void SetMember(string name, XeValue value) =>
        Fields.Assign(name, value);

    public string ToDisplayString()
    {
        var sb = new System.Text.StringBuilder();
        sb.Append($"{BlueprintName}{{");
        var pairs = Fields.GetAll()
            .Select(kv => $"{kv.Key}: {kv.Value.ToDisplayString()}");
        sb.Append(string.Join(", ", pairs));
        sb.Append('}');
        return sb.ToString();
    }

    public override string ToString() => ToDisplayString();
}

/// <summary>A blueprint (class) definition at runtime.</summary>
public sealed class XeBlueprint
{
    public string             Name      { get; }
    public XeBlueprint?       Parent    { get; }
    public ICallable?         Constructor { get; init; }

    private readonly Dictionary<string, ICallable>  _methods = new();
    private readonly Dictionary<string, XeValue>    _fields  = new();

    public IReadOnlyDictionary<string, XeValue> AllFields
    {
        get
        {
            var all = new Dictionary<string, XeValue>();
            if (Parent is not null)
                foreach (var kv in Parent.AllFields) all[kv.Key] = kv.Value;
            foreach (var kv in _fields) all[kv.Key] = kv.Value;
            return all;
        }
    }

    public XeBlueprint(string name, XeBlueprint? parent = null)
    {
        Name   = name;
        Parent = parent;
    }

    public void AddField(string name, XeValue defaultValue) =>
        _fields[name] = defaultValue;

    public void AddMethod(string name, ICallable method) =>
        _methods[name] = method;

    public bool TryGetMethod(string name, out ICallable method)
    {
        if (_methods.TryGetValue(name, out method!)) return true;
        return Parent?.TryGetMethod(name, out method!) ?? false;
    }
}
