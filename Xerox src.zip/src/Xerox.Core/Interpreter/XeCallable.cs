using Xerox.Core.Errors;
using Xerox.Core.Parsing.AST;

namespace Xerox.Core.Interpreter;

// ── User-defined function (closure) ──────────────────────────────────────────

/// <summary>A Xerox function value capturing its declaration and closure environment.</summary>
public sealed class XeFunction : ICallable
{
    internal readonly FunctionDeclStmt _decl;
    internal readonly XeEnvironment    _closure;

    public string Name  => _decl.Name;
    public int    Arity => _decl.Params.Count;

    public XeFunction(FunctionDeclStmt decl, XeEnvironment closure)
    {
        _decl    = decl;
        _closure = closure;
    }

    public XeValue Call(Interpreter interpreter, IReadOnlyList<XeValue> args)
    {
        var env = _closure.CreateChild();

        // bind positional parameters
        for (int i = 0; i < _decl.Params.Count; i++)
        {
            var p = _decl.Params[i];
            var v = i < args.Count ? args[i]
                  : p.Default is not null ? interpreter.EvalExpr(p.Default, env)
                  : XeValue.Nothing;
            env.Define(p.Name, v);
        }

        try
        {
            interpreter.ExecBlock(_decl.Body, env);
            return XeValue.Nothing;
        }
        catch (ReturnSignal sig)
        {
            return (sig.Value as XeValue) ?? XeValue.Nothing;
        }
    }

    public override string ToString() => $"<function {Name}>";
}

// ── Bound method ─────────────────────────────────────────────────────────────

/// <summary>A method bound to a particular XeObject instance.</summary>
public sealed class XeMethod : ICallable
{
    private readonly XeFunction _fn;
    private readonly XeObject   _instance;

    public string Name  => _fn.Name;
    public int    Arity => _fn.Arity;

    public XeMethod(XeFunction fn, XeObject instance)
    {
        _fn       = fn;
        _instance = instance;
    }

    public XeValue Call(Interpreter interpreter, IReadOnlyList<XeValue> args)
    {
        // Inject 'itself' / 'self' into the execution environment
        var env = _fn._closure.CreateChild();
        env.Define("itself", XeValue.FromObject(_instance));
        env.Define("self",   XeValue.FromObject(_instance));

        for (int i = 0; i < _fn._decl.Params.Count; i++)
        {
            var p = _fn._decl.Params[i];
            var v = i < args.Count ? args[i]
                  : p.Default is not null ? interpreter.EvalExpr(p.Default, env)
                  : XeValue.Nothing;
            env.Define(p.Name, v);
        }

        try
        {
            interpreter.ExecBlock(_fn._decl.Body, env);
            return XeValue.Nothing;
        }
        catch (ReturnSignal sig)
        {
            return (sig.Value as XeValue) ?? XeValue.Nothing;
        }
    }
}

// XeMethod directly accesses internal fields — no reflection needed.

// ── Native / built-in functions ───────────────────────────────────────────────

/// <summary>
/// A function implemented in C# and exposed to Xerox programs.
/// </summary>
public sealed class NativeFunction : ICallable
{
    private readonly Func<Interpreter, IReadOnlyList<XeValue>, XeValue> _impl;

    public string Name  { get; }
    public int    Arity { get; }

    public NativeFunction(string name, int arity,
        Func<Interpreter, IReadOnlyList<XeValue>, XeValue> impl)
    {
        Name   = name;
        Arity  = arity;
        _impl  = impl;
    }

    public XeValue Call(Interpreter interpreter, IReadOnlyList<XeValue> args) =>
        _impl(interpreter, args);

    public override string ToString() => $"<native {Name}>";
}

/// <summary>Blueprint constructor wrapper.</summary>
public sealed class XeConstructor : ICallable
{
    private readonly XeBlueprint      _blueprint;
    private readonly FunctionDeclStmt? _ctorDecl;
    private readonly XeEnvironment    _closure;

    public string     Name      => _blueprint.Name;
    public int        Arity     => _ctorDecl?.Params.Count ?? 0;
    public XeBlueprint Blueprint => _blueprint;

    public XeConstructor(XeBlueprint blueprint, FunctionDeclStmt? ctorDecl, XeEnvironment closure)
    {
        _blueprint = blueprint;
        _ctorDecl  = ctorDecl;
        _closure   = closure;
    }

    public XeValue Call(Interpreter interpreter, IReadOnlyList<XeValue> args)
    {
        var instance = new XeObject(_blueprint);

        if (_ctorDecl is not null)
        {
            var env = _closure.CreateChild();
            env.Define("itself", XeValue.FromObject(instance));
            env.Define("self",   XeValue.FromObject(instance));

            for (int i = 0; i < _ctorDecl.Params.Count; i++)
            {
                var p = _ctorDecl.Params[i];
                var v = i < args.Count ? args[i]
                      : p.Default is not null ? interpreter.EvalExpr(p.Default, env)
                      : XeValue.Nothing;
                env.Define(p.Name, v);
            }

            try   { interpreter.ExecBlock(_ctorDecl.Body, env); }
            catch (ReturnSignal)  { /* constructors may return early */ }
        }

        return XeValue.FromObject(instance);
    }
}