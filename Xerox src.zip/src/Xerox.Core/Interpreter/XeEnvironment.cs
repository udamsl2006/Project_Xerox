namespace Xerox.Core.Interpreter;

/// <summary>
/// A lexical scope that maps names to XeValues.
/// Environments form a linked chain (child → parent) for lexical scoping.
/// </summary>
public sealed class XeEnvironment
{
    private readonly Dictionary<string, XeValue> _vars = new(StringComparer.Ordinal);
    private readonly XeEnvironment? _parent;

    public XeEnvironment(XeEnvironment? parent = null) => _parent = parent;

    // ── Variable operations ───────────────────────────────────────────────────

    /// <summary>Declare a new variable in THIS scope.</summary>
    public void Define(string name, XeValue value) =>
        _vars[name] = value;

    /// <summary>Assign to an existing variable (walks up scope chain).</summary>
    public void Assign(string name, XeValue value)
    {
        if (_vars.ContainsKey(name)) { _vars[name] = value; return; }
        if (_parent is not null)     { _parent.Assign(name, value); return; }
        // Auto-define in current scope if not found (lenient mode)
        _vars[name] = value;
    }

    /// <summary>Look up a variable (walks up scope chain).</summary>
    public XeValue Get(string name)
    {
        if (_vars.TryGetValue(name, out var v)) return v;
        if (_parent is not null) return _parent.Get(name);
        throw new Errors.XeroxRuntimeException($"Undefined variable '{name}'.", 0, 0);
    }

    /// <summary>Look up without throwing; returns false if not found.</summary>
    public bool TryGet(string name, out XeValue value)
    {
        if (_vars.TryGetValue(name, out value!)) return true;
        if (_parent is not null) return _parent.TryGet(name, out value!);
        value = XeValue.Nothing;
        return false;
    }

    /// <summary>Returns true if the name exists anywhere in the scope chain.</summary>
    public bool Exists(string name) =>
        _vars.ContainsKey(name) || (_parent?.Exists(name) ?? false);

    /// <summary>All variables directly defined in THIS scope (not parents).</summary>
    public IEnumerable<KeyValuePair<string, XeValue>> GetAll() => _vars;

    /// <summary>Creates a child scope that inherits from this one.</summary>
    public XeEnvironment CreateChild() => new XeEnvironment(this);

    /// <summary>The enclosing scope (null for global scope).</summary>
    public XeEnvironment? Parent => _parent;
}
