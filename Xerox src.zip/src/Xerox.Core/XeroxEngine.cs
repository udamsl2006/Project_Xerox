using Xerox.Core.Errors;
using Xerox.Core.Interpreter;
using Xerox.Core.Lexing;
using Xerox.Core.Parsing;

namespace Xerox.Core;

/// <summary>
/// High-level facade for running Xerox programs.
/// Combines the Lexer → Parser → Interpreter pipeline.
/// </summary>
public sealed class XeroxEngine
{
    // ── Configuration ─────────────────────────────────────────────────────────

    public TextWriter Output  { get => _interpreter.Output;  set => _interpreter.Output = value; }
    public TextReader Input   { get => _interpreter.Input;   set => _interpreter.Input  = value; }
    public bool       Verbose { get => _interpreter.Verbose; set => _interpreter.Verbose = value; }

    private readonly Interpreter.Interpreter _interpreter = new();

    /// <summary>Direct access to the global environment for embedding use-cases.</summary>
    public XeEnvironment Globals => _interpreter.Globals;

    // ── Run from source ───────────────────────────────────────────────────────

    /// <summary>
    /// Lex, parse and execute <paramref name="source"/>.
    /// Returns an <see cref="ExecutionResult"/> containing any diagnostics.
    /// </summary>
    public ExecutionResult Run(string source, string file = "<input>")
    {
        // 1. Lex
        var lexResult = Lexer.Tokenize(source, file);
        if (lexResult.HasErrors)
            return ExecutionResult.Failure(lexResult.Errors, Phase.Lex);

        // 2. Parse
        // BUG FIX: was throwing InvalidOperationException instead of returning
        // ExecutionResult.Failure, making parse errors inconsistent with lex errors.
        var parseResult = Parser.Parse(lexResult.Tokens, file);
        if (parseResult.HasErrors)
            return ExecutionResult.Failure(parseResult.Errors, Phase.Parse);

        // 3. Execute
        try
        {
            _interpreter.Run(parseResult.Program);
            return ExecutionResult.Success();
        }
        catch (XeroxRuntimeException ex)
        {
            System.Console.Error.WriteLine($"[XEROX RUNTIME ERROR] {ex.Error}");
            return ExecutionResult.Failure(new[] { ex.Error }, Phase.Runtime);
        }
        catch (Exception ex)
        {
            System.Console.Error.WriteLine($"[XEROX INTERNAL ERROR] {ex.GetType().Name}: {ex.Message}" + Environment.NewLine + ex.StackTrace);
            var error = new RuntimeError($"Internal error: {ex.Message}", 0, 0, file);
            return ExecutionResult.Failure(new[] { (XeroxError)error }, Phase.Runtime);
        }
    }

    /// <summary>
    /// Load and run a Xerox source file from disk.
    /// </summary>
    public ExecutionResult RunFile(string path)
    {
        if (!File.Exists(path))
        {
            var err = new RuntimeError($"File not found: '{path}'", 0, 0, path);
            return ExecutionResult.Failure(new[] { (XeroxError)err }, Phase.Runtime);
        }

        string source;
        try { source = File.ReadAllText(path); }
        catch (Exception ex)
        {
            var err = new RuntimeError($"Cannot read file '{path}': {ex.Message}", 0, 0, path);
            return ExecutionResult.Failure(new[] { (XeroxError)err }, Phase.Runtime);
        }

        return Run(source, path);
    }

    /// <summary>
    /// Evaluate a single expression and return its string representation.
    /// Useful for REPL evaluation.
    /// </summary>
    public (XeValue? Value, ExecutionResult Result) Eval(string expression, string file = "<repl>")
    {
        var lexResult = Lexer.Tokenize(expression, file);
        if (lexResult.HasErrors)
            return (null, ExecutionResult.Failure(lexResult.Errors, Phase.Lex));

        var parseResult = Parser.Parse(lexResult.Tokens, file);
        if (parseResult.HasErrors)
            return (null, ExecutionResult.Failure(parseResult.Errors, Phase.Parse));

        // If the last statement is an expression statement, return its value
        var stmts = parseResult.Program.Statements;
        if (stmts.Count > 0 && stmts[^1] is Parsing.AST.ExpressionStmt last)
        {
            try
            {
                // Run all but last as statements
                var head = stmts.Take(stmts.Count - 1).ToList();
                if (head.Count > 0)
                {
                    var block = new Parsing.AST.BlockStmt
                    {
                        Statements = head,
                        SourceToken = last.SourceToken
                    };
                    _interpreter.ExecBlock(block, Globals);
                }
                var value = _interpreter.EvalExpr(last.Expr, Globals);
                return (value, ExecutionResult.Success());
            }
            catch (XeroxRuntimeException ex)
            {
                return (null, ExecutionResult.Failure(new[] { ex.Error }, Phase.Runtime));
            }
        }

        var res = Run(expression, file);
        return (null, res);
    }

    /// <summary>Format and print all errors to the output writer.</summary>
    public void PrintErrors(ExecutionResult result, string[]? sourceLines = null)
    {
        foreach (var error in result.Errors)
        {
            if (sourceLines is not null)
                Output.Write(error.FormatFull(sourceLines));
            else
                Output.WriteLine(error.ToString());
        }
    }
}

// ── Result types ─────────────────────────────────────────────────────────────

public sealed class ExecutionResult
{
    public bool                      IsSuccess { get; }
    public IReadOnlyList<XeroxError> Errors    { get; }
    public Phase                     FailedAt  { get; }

    private ExecutionResult(bool success, IReadOnlyList<XeroxError> errors, Phase phase)
    {
        IsSuccess = success;
        Errors    = errors;
        FailedAt  = phase;
    }

    public static ExecutionResult Success()
        => new(true, Array.Empty<XeroxError>(), Phase.None);

    public static ExecutionResult Failure(IEnumerable<XeroxError> errors, Phase phase)
        => new(false, errors.ToList(), phase);
}

public enum Phase { None, Lex, Parse, Semantic, Runtime }
