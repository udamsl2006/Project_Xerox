using Xerox.Core.Errors;

namespace Xerox.Core.Lexing;

/// <summary>
/// Xerox language lexer.  Converts source text into a flat list of tokens.
/// Thread-safe: each call to Tokenize creates an independent scanner state.
/// </summary>
public sealed class Lexer
{
    // ── Keyword table ─────────────────────────────────────────────────────────
    private static readonly Dictionary<string, TokenType> Keywords = new(StringComparer.OrdinalIgnoreCase)
    {
        // declarations
        ["create"]      = TokenType.Create,
        ["with"]        = TokenType.With,
        ["value"]       = TokenType.Value,
        ["as"]          = TokenType.As,
        ["set"]         = TokenType.Set,
        ["to"]          = TokenType.To,
        ["let"]         = TokenType.Let,

        // types
        ["number"]      = TokenType.TypeNumber,
        ["text"]        = TokenType.TypeText,
        ["bool"]        = TokenType.TypeBool,
        ["boolean"]     = TokenType.TypeBool,
        ["list"]        = TokenType.TypeList,
        ["object"]      = TokenType.TypeObject,
        ["any"]         = TokenType.TypeAny,

        // functions
        ["define"]      = TokenType.Define,
        ["function"]    = TokenType.Function,
        ["procedure"]   = TokenType.Function,
        ["that"]        = TokenType.That,
        ["takes"]       = TokenType.Takes,
        ["accepts"]     = TokenType.Takes,
        ["and"]         = TokenType.And,
        ["returns"]     = TokenType.Returns,
        ["return"]      = TokenType.Return,
        ["call"]        = TokenType.Call,
        ["invoke"]      = TokenType.Call,
        ["end"]         = TokenType.End,
        ["give"]        = TokenType.Give,
        ["back"]        = TokenType.Back,

        // class / OOP
        ["blueprint"]   = TokenType.Blueprint,
        ["class"]       = TokenType.Blueprint,
        ["has"]         = TokenType.Has,
        ["knows"]       = TokenType.Knows,
        ["how"]         = TokenType.How,
        ["build"]       = TokenType.Build,
        ["constructor"] = TokenType.Build,
        ["itself"]      = TokenType.Itself,
        ["self"]        = TokenType.Itself,
        ["new"]         = TokenType.New,
        ["of"]          = TokenType.Of,
        ["extend"]      = TokenType.Extend,
        ["extends"]     = TokenType.Extend,
        ["inherits"]    = TokenType.Extend,
        ["from"]        = TokenType.From,

        // control flow
        ["if"]          = TokenType.If,
        ["then"]        = TokenType.Then,
        ["otherwise"]   = TokenType.Otherwise,
        ["else"]        = TokenType.Otherwise,
        ["while"]       = TokenType.While,
        ["repeat"]      = TokenType.Repeat,
        ["times"]       = TokenType.Times,
        ["for"]         = TokenType.For,
        ["each"]        = TokenType.Each,
        ["every"]       = TokenType.Each,
        ["in"]          = TokenType.In,
        ["break"]       = TokenType.Break,
        ["stop"]        = TokenType.Break,
        ["continue"]    = TokenType.Continue,
        ["skip"]        = TokenType.Skip,

        // boolean / comparison
        ["is"]          = TokenType.Is,
        ["not"]         = TokenType.Not,
        ["greater"]     = TokenType.Greater,
        ["less"]        = TokenType.Less,
        ["than"]        = TokenType.Than,
        ["equal"]       = TokenType.Equal,
        ["equals"]      = TokenType.Equal,
        ["or"]          = TokenType.Or,
        ["neither"]     = TokenType.Neither,
        ["nor"]         = TokenType.Nor,
        ["both"]        = TokenType.Both,

        // arithmetic
        ["plus"]        = TokenType.Plus,
        ["minus"]       = TokenType.Minus,
        ["multiplied"]  = TokenType.Times2,
        ["divided"]     = TokenType.Divided,
        ["by"]          = TokenType.By,
        ["modulo"]      = TokenType.Modulo,
        ["remainder"]   = TokenType.Modulo,

        // string
        ["joined"]      = TokenType.Joined,
        ["length"]      = TokenType.Length,
        ["contains"]    = TokenType.Contains,
        ["starts"]      = TokenType.Starts,
        ["ends"]        = TokenType.Ends,

        // list
        ["add"]         = TokenType.Add,
        ["append"]      = TokenType.Add,
        ["remove"]      = TokenType.Remove,
        ["delete"]      = TokenType.Remove,
        ["at"]          = TokenType.At,
        ["index"]       = TokenType.Index,
        ["count"]       = TokenType.Count,
        ["size"]        = TokenType.Count,
        ["empty"]       = TokenType.Empty,
        ["clear"]       = TokenType.Empty,

        // IO
        ["display"]     = TokenType.Display,
        ["print"]       = TokenType.Display,
        ["show"]        = TokenType.Display,
        ["ask"]         = TokenType.Ask,
        ["prompt"]      = TokenType.Ask,
        ["read"]        = TokenType.Read,

        // math builtins
        ["absolute"]    = TokenType.Absolute,
        ["round"]       = TokenType.Round,
        ["floor"]       = TokenType.Floor,
        ["ceiling"]     = TokenType.Ceiling,
        ["squareroot"]  = TokenType.Sqrt,
        ["sqrt"]        = TokenType.Sqrt,
        ["power"]       = TokenType.Power,
        ["random"]      = TokenType.Random,

        // literals
        ["true"]        = TokenType.True,
        ["yes"]         = TokenType.True,
        ["false"]       = TokenType.False,
        ["no"]          = TokenType.False,
        ["nothing"]     = TokenType.Nothing,
        ["null"]        = TokenType.Nothing,
        ["none"]        = TokenType.Nothing,
    };

    // ── Scanner state ─────────────────────────────────────────────────────────
    private readonly string _source;
    private readonly string _file;
    private readonly List<Token>   _tokens  = new();
    private readonly List<XeroxError> _errors = new();

    private int _start   = 0;
    private int _current = 0;
    private int _line    = 1;
    private int _lineStart = 0;   // index of first char of current line

    private Lexer(string source, string file)
    {
        _source = source;
        _file   = file;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /// <summary>
    /// Tokenise <paramref name="source"/> and return the token list.
    /// Throws <see cref="LexerException"/> if any lexical errors were found.
    /// </summary>
    public static LexResult Tokenize(string source, string file = "<input>")
    {
        var lexer = new Lexer(source, file);
        lexer.ScanAll();
        return new LexResult(lexer._tokens, lexer._errors);
    }

    // ── Core scanning loop ────────────────────────────────────────────────────

    private void ScanAll()
    {
        while (!IsAtEnd())
        {
            _start = _current;
            ScanToken();
        }
        _tokens.Add(MakeToken(TokenType.EOF, string.Empty, null));
    }

    private void ScanToken()
    {
        char c = Advance();
        switch (c)
        {
            // whitespace (not newlines)
            case ' ':
            case '\r':
            case '\t':
                break;

            // newline — significant as statement separator
            case '\n':
                AddToken(TokenType.Newline);
                _line++;
                _lineStart = _current;
                break;

            // single-char symbols
            case '(': AddToken(TokenType.LeftParen);    break;
            case ')': AddToken(TokenType.RightParen);   break;
            case '[': AddToken(TokenType.LeftBracket);  break;
            case ']': AddToken(TokenType.RightBracket); break;
            case ',': AddToken(TokenType.Comma);        break;
            case '.': AddToken(TokenType.Dot);          break;
            case ':': AddToken(TokenType.Colon);        break;
            case '?': AddToken(TokenType.QuestionMark); break;
            case '%': AddToken(TokenType.SymPercent);   break;

            case '+': AddToken(TokenType.SymPlus);   break;
            case '*': AddToken(TokenType.SymStar);   break;
            case '/':
                if (Peek() == '/')      { SkipLineComment(); }
                else if (Peek() == '*') { SkipBlockComment(); }
                else                    { AddToken(TokenType.SymSlash); }
                break;

            case '-':
                if (Peek() == '>') { Advance(); AddToken(TokenType.Arrow); }
                else               { AddToken(TokenType.SymMinus); }
                break;

            case '=':
                if (Peek() == '=') { Advance(); AddToken(TokenType.SymEqualEqual); }
                else               { AddToken(TokenType.SymEqual); }
                break;

            case '!':
                if (Peek() == '=') { Advance(); AddToken(TokenType.SymNotEqual); }
                else               { AddToken(TokenType.SymBang); }
                break;

            case '<':
                if (Peek() == '=') { Advance(); AddToken(TokenType.SymLte); }
                else               { AddToken(TokenType.SymLt); }
                break;

            case '>':
                if (Peek() == '=') { Advance(); AddToken(TokenType.SymGte); }
                else               { AddToken(TokenType.SymGt); }
                break;

            case '&':
                if (Peek() == '&') { Advance(); AddToken(TokenType.SymAmpAmp); }
                else               { ReportError("Unexpected '&'. Did you mean '&&'?"); }
                break;

            case '|':
                if (Peek() == '|') { Advance(); AddToken(TokenType.SymPipePipe); }
                else               { ReportError("Unexpected '|'. Did you mean '||'?"); }
                break;

            // string literals
            case '"': ScanString('"');  break;
            case '\'': ScanString('\''); break;

            default:
                if (char.IsDigit(c))        { ScanNumber(); }
                else if (IsIdentStart(c))   { ScanIdentifierOrKeyword(); }
                else                        { ReportError($"Unexpected character '{c}'."); }
                break;
        }
    }

    // ── Scanning helpers ──────────────────────────────────────────────────────

    private void ScanString(char closing)
    {
        var sb = new System.Text.StringBuilder();
        while (!IsAtEnd() && Peek() != closing)
        {
            if (Peek() == '\n') { _line++; _lineStart = _current + 1; }

            if (Peek() == '\\')
            {
                Advance(); // consume backslash
                char esc = Advance();
                sb.Append(esc switch
                {
                    'n'  => '\n',
                    't'  => '\t',
                    'r'  => '\r',
                    '\\' => '\\',
                    '"'  => '"',
                    '\'' => '\'',
                    '0'  => '\0',
                    _    => esc   // pass through unknown escapes
                });
            }
            else
            {
                sb.Append(Advance());
            }
        }

        if (IsAtEnd())
        {
            ReportError("Unterminated string literal.");
            return;
        }

        Advance(); // closing quote
        _tokens.Add(MakeToken(TokenType.Text, sb.ToString(), sb.ToString()));
    }

    private void ScanNumber()
    {
        while (!IsAtEnd() && char.IsDigit(Peek())) Advance();

        bool isFloat = false;
        if (Peek() == '.' && char.IsDigit(PeekNext()))
        {
            isFloat = true;
            Advance(); // '.'
            while (!IsAtEnd() && char.IsDigit(Peek())) Advance();
        }

        string raw = _source[_start.._current];
        if (!double.TryParse(raw, System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out double val))
        {
            ReportError($"Invalid numeric literal '{raw}'.");
            return;
        }
        _ = isFloat; // future use for integer vs float distinction
        _tokens.Add(MakeToken(TokenType.Number, raw, val));
    }

    private void ScanIdentifierOrKeyword()
    {
        while (!IsAtEnd() && IsIdentPart(Peek())) Advance();
        string text = _source[_start.._current];

        if (Keywords.TryGetValue(text, out TokenType kwType))
        {
            // map keyword literals to their literal values
            object? lit = kwType switch
            {
                TokenType.True    => true,
                TokenType.False   => false,
                TokenType.Nothing => null,
                _                 => null
            };
            _tokens.Add(MakeToken(kwType, text, lit));
        }
        else
        {
            _tokens.Add(MakeToken(TokenType.Identifier, text, null));
        }
    }

    private void SkipLineComment()
    {
        while (!IsAtEnd() && Peek() != '\n') Advance();
    }

    private void SkipBlockComment()
    {
        Advance(); // consume '*'
        int depth = 1;
        while (!IsAtEnd() && depth > 0)
        {
            if (Peek() == '/' && PeekNext() == '*')  { Advance(); Advance(); depth++; }
            else if (Peek() == '*' && PeekNext() == '/') { Advance(); Advance(); depth--; }
            else
            {
                if (Peek() == '\n') { _line++; _lineStart = _current + 1; }
                Advance();
            }
        }
        if (depth > 0) ReportError("Unterminated block comment.");
    }

    // ── Character helpers ─────────────────────────────────────────────────────

    private char Advance()      => _source[_current++];
    private char Peek()         => IsAtEnd() ? '\0' : _source[_current];
    private char PeekNext()     => (_current + 1 >= _source.Length) ? '\0' : _source[_current + 1];
    private bool IsAtEnd()      => _current >= _source.Length;
    private static bool IsIdentStart(char c) => char.IsLetter(c) || c == '_';
    private static bool IsIdentPart(char c)  => char.IsLetterOrDigit(c) || c == '_';

    // ── Token factories ───────────────────────────────────────────────────────

    private void AddToken(TokenType type) =>
        _tokens.Add(MakeToken(type, _source[_start.._current], null));

    private Token MakeToken(TokenType type, string lexeme, object? literal)
    {
        int col = _start - _lineStart + 1;
        return new Token(type, lexeme, literal, _line, col, _file);
    }

    // ── Error reporting ───────────────────────────────────────────────────────

    private void ReportError(string message)
    {
        int col = _start - _lineStart + 1;
        _errors.Add(new LexerError(message, _line, col, _file));

        // insert Unknown token so the token stream stays aligned
        _tokens.Add(MakeToken(TokenType.Unknown, _source[_start.._current], null));
    }
}

/// <summary>Result of lexing: tokens + any errors found.</summary>
public sealed class LexResult
{
    public IReadOnlyList<Token>      Tokens { get; }
    public IReadOnlyList<XeroxError> Errors { get; }
    public bool HasErrors => Errors.Count > 0;

    public LexResult(IReadOnlyList<Token> tokens, IReadOnlyList<XeroxError> errors)
    {
        Tokens = tokens;
        Errors = errors;
    }
}
