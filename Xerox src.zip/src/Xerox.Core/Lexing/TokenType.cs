namespace Xerox.Core.Lexing;

/// <summary>
/// All token types recognized by the Xerox lexer.
/// </summary>
public enum TokenType
{
    // ── Literals ──────────────────────────────────────────────────────────────
    Number,         // 42  3.14
    Text,           // "hello"
    True,           // true
    False,          // false
    Nothing,        // nothing  (null equivalent)

    // ── Identifiers ──────────────────────────────────────────────────────────
    Identifier,

    // ── Declaration keywords ──────────────────────────────────────────────────
    Create,         // create
    With,           // with
    Value,          // value
    As,             // as
    Set,            // set
    To,             // to
    Let,            // let  (alias for set)

    // ── Type keywords ─────────────────────────────────────────────────────────
    TypeNumber,     // number
    TypeText,       // text
    TypeBool,       // bool
    TypeList,       // list
    TypeObject,     // object
    TypeAny,        // any

    // ── Function keywords ─────────────────────────────────────────────────────
    Define,         // define
    Function,       // function
    That,           // that
    Takes,          // takes
    And,            // and
    Returns,        // returns
    Return,         // return
    Call,           // call
    End,            // end
    Give,           // give  (alias for return)
    Back,           // back  (give back x)

    // ── Class / Object keywords ───────────────────────────────────────────────
    Blueprint,      // blueprint  (class declaration)
    Has,            // has         (field declaration)
    Knows,          // knows       (method declaration)
    How,            // how         (knows how to)
    Build,          // build       (constructor)
    Itself,         // itself      (self reference)
    New,            // new         (new instance)
    Of,             // of
    Extend,         // extend      (inheritance)
    From,           // from

    // ── Control flow ──────────────────────────────────────────────────────────
    If,             // if
    Then,           // then
    Otherwise,      // otherwise  (else)
    Else,           // else
    While,          // while
    Repeat,         // repeat
    Times,          // times
    For,            // for
    Each,           // each
    In,             // in
    Break,          // break
    Continue,       // continue  (skip)
    Skip,           // skip      (alias for continue)

    // ── Boolean / comparison operators ────────────────────────────────────────
    Is,             // is
    Not,            // not
    Greater,        // greater
    Less,           // less
    Than,           // than
    Equal,          // equal  / equals
    Or,             // or
    Neither,        // neither
    Nor,            // nor
    Both,           // both

    // ── Arithmetic operators ──────────────────────────────────────────────────
    Plus,           // plus
    Minus,          // minus
    Times2,         // multiplied  / times
    Divided,        // divided
    By,             // by
    Modulo,         // modulo / remainder

    // ── String operators ──────────────────────────────────────────────────────
    Joined,         // joined
    Length,         // length
    Contains,       // contains
    Starts,         // starts
    Ends,           // ends
    // With2 removed: "with" always lexes as With

    // ── List/collection ───────────────────────────────────────────────────────
    Add,            // add
    Remove,         // remove
    At,             // at
    Index,          // index
    Count,          // count
    Empty,          // empty

    // ── IO ────────────────────────────────────────────────────────────────────
    Display,        // display
    Ask,            // ask
    Read,           // read

    // ── Math builtins ─────────────────────────────────────────────────────────
    Absolute,       // absolute
    Round,          // round
    Floor,          // floor
    Ceiling,        // ceiling
    Sqrt,           // squareroot
    Power,          // power
    Random,         // random

    // ── Punctuation & Symbols ─────────────────────────────────────────────────
    Comma,          // ,
    Dot,            // .
    Colon,          // :
    LeftParen,      // (
    RightParen,     // )
    LeftBracket,    // [
    RightBracket,   // ]
    Arrow,          // ->
    QuestionMark,   // ?

    // ── Symbolic operators (allowed inline) ───────────────────────────────────
    SymPlus,        // +
    SymMinus,       // -
    SymStar,        // *
    SymSlash,       // /
    SymPercent,     // %
    SymEqualEqual,  // ==
    SymNotEqual,    // !=
    SymLt,          // <
    SymLte,         // <=
    SymGt,          // >
    SymGte,         // >=
    SymEqual,       // =   (assignment shorthand)
    SymAmpAmp,      // &&
    SymPipePipe,    // ||
    SymBang,        // !

    // ── Special ───────────────────────────────────────────────────────────────
    Newline,
    EOF,
    Unknown
}
