namespace Xerox.Core.Lexing;

/// <summary>
/// A single token produced by the Xerox lexer.
/// Carries source position for high-quality error messages.
/// </summary>
public sealed class Token
{
    public TokenType Type     { get; }
    public string    Lexeme   { get; }   // raw text from source
    public object?   Literal  { get; }   // parsed literal value (double / string / bool)
    public int       Line     { get; }
    public int       Column   { get; }
    public string    File     { get; }

    public Token(TokenType type, string lexeme, object? literal, int line, int column, string file = "<input>")
    {
        Type    = type;
        Lexeme  = lexeme;
        Literal = literal;
        Line    = line;
        Column  = column;
        File    = file;
    }

    public override string ToString() =>
        $"[{Type} '{Lexeme}' @ {File}:{Line}:{Column}]";
}
