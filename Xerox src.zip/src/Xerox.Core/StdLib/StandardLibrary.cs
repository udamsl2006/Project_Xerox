using Xerox.Core.Interpreter;

namespace Xerox.Core.StdLib;

/// <summary>
/// Registers all built-in functions into the global environment.
/// </summary>
public static class StandardLibrary
{
    public static void Register(XeEnvironment env)
    {
        RegisterIO(env);
        RegisterMath(env);
        RegisterString(env);
        RegisterCollections(env);
        RegisterConversions(env);
        RegisterSystem(env);
    }

    // ─── IO ───────────────────────────────────────────────────────────────────

    private static void RegisterIO(XeEnvironment env)
    {
        Def(env, "display", -1, (_, args) =>
        {
            Console.WriteLine(string.Join(" ", args.Select(a => a.ToDisplayString())));
            return XeValue.Nothing;
        });

        Def(env, "print", -1, (_, args) =>
        {
            Console.Write(string.Join(" ", args.Select(a => a.ToDisplayString())));
            return XeValue.Nothing;
        });

        Def(env, "ask", 1, (_, args) =>
        {
            Console.Write(args[0].ToDisplayString());
            return XeValue.FromString(Console.ReadLine() ?? "");
        });

        Def(env, "readLine", 0, (_, _) =>
            XeValue.FromString(Console.ReadLine() ?? ""));

        Def(env, "readNumber", 0, (_, _) =>
        {
            var line = Console.ReadLine() ?? "";
            return double.TryParse(line, out double d)
                ? XeValue.FromDouble(d)
                : XeValue.Nothing;
        });
    }

    // ─── Math ─────────────────────────────────────────────────────────────────

    private static void RegisterMath(XeEnvironment env)
    {
        Def(env, "abs",     1, (_, a) => XeValue.FromDouble(Math.Abs(a[0].AsNumber())));
        Def(env, "round",   1, (_, a) => XeValue.FromDouble(Math.Round(a[0].AsNumber(), MidpointRounding.AwayFromZero)));
        Def(env, "floor",   1, (_, a) => XeValue.FromDouble(Math.Floor(a[0].AsNumber())));
        Def(env, "ceiling", 1, (_, a) => XeValue.FromDouble(Math.Ceiling(a[0].AsNumber())));
        Def(env, "ceil",    1, (_, a) => XeValue.FromDouble(Math.Ceiling(a[0].AsNumber())));
        Def(env, "sqrt",    1, (_, a) => XeValue.FromDouble(Math.Sqrt(a[0].AsNumber())));
        Def(env, "pow",     2, (_, a) => XeValue.FromDouble(Math.Pow(a[0].AsNumber(), a[1].AsNumber())));
        Def(env, "sin",     1, (_, a) => XeValue.FromDouble(Math.Sin(a[0].AsNumber())));
        Def(env, "cos",     1, (_, a) => XeValue.FromDouble(Math.Cos(a[0].AsNumber())));
        Def(env, "tan",     1, (_, a) => XeValue.FromDouble(Math.Tan(a[0].AsNumber())));
        Def(env, "log",     1, (_, a) => XeValue.FromDouble(Math.Log(a[0].AsNumber())));
        Def(env, "log10",   1, (_, a) => XeValue.FromDouble(Math.Log10(a[0].AsNumber())));
        Def(env, "exp",     1, (_, a) => XeValue.FromDouble(Math.Exp(a[0].AsNumber())));
        Def(env, "max",     2, (_, a) => XeValue.FromDouble(Math.Max(a[0].AsNumber(), a[1].AsNumber())));
        Def(env, "min",     2, (_, a) => XeValue.FromDouble(Math.Min(a[0].AsNumber(), a[1].AsNumber())));
        Def(env, "clamp",   3, (_, a) =>
            XeValue.FromDouble(Math.Clamp(a[0].AsNumber(), a[1].AsNumber(), a[2].AsNumber())));

        var rng = new Random();
        Def(env, "random", 0, (_, _) => XeValue.FromDouble(rng.NextDouble()));
        Def(env, "randomInt", 2, (_, a) =>
        {
            int lo = (int)a[0].AsNumber(), hi = (int)a[1].AsNumber();
            return XeValue.FromDouble(rng.Next(lo, hi + 1));
        });

        // Math constants
        env.Define("PI",       XeValue.FromDouble(Math.PI));
        env.Define("E",        XeValue.FromDouble(Math.E));
        env.Define("INFINITY", XeValue.FromDouble(double.PositiveInfinity));
        env.Define("NAN",      XeValue.FromDouble(double.NaN));
    }

    // ─── String ───────────────────────────────────────────────────────────────

    private static void RegisterString(XeEnvironment env)
    {
        Def(env, "upper",       1, (_, a) => XeValue.FromString(a[0].AsString().ToUpperInvariant()));
        Def(env, "lower",       1, (_, a) => XeValue.FromString(a[0].AsString().ToLowerInvariant()));
        Def(env, "trim",        1, (_, a) => XeValue.FromString(a[0].AsString().Trim()));
        Def(env, "trimStart",   1, (_, a) => XeValue.FromString(a[0].AsString().TrimStart()));
        Def(env, "trimEnd",     1, (_, a) => XeValue.FromString(a[0].AsString().TrimEnd()));
        Def(env, "length",      1, (_, a) => XeValue.FromDouble(a[0].AsString().Length));

        // BUG FIX: "reverse" was registered in BOTH RegisterString and RegisterCollections.
        // The collections version (which calls AsList()) overwrote the string version,
        // causing string reverse to throw at runtime. Fixed by using a unified "reverseStr"
        // name here and keeping "reverse" only in RegisterCollections (which handles both types).
        Def(env, "reverseText", 1, (_, a) =>
        {
            var arr = a[0].AsString().ToCharArray();
            Array.Reverse(arr);
            return XeValue.FromString(new string(arr));
        });

        Def(env, "split",       2, (_, a) =>
        {
            var parts = a[0].AsString().Split(a[1].AsString());
            return XeValue.FromList(parts.Select(XeValue.FromString).ToList());
        });
        Def(env, "join",        2, (_, a) =>
        {
            var sep  = a[0].AsString();
            var list = a[1].AsList();
            return XeValue.FromString(string.Join(sep, list.Select(v => v.ToDisplayString())));
        });
        Def(env, "replace",     3, (_, a) =>
            XeValue.FromString(a[0].AsString().Replace(a[1].AsString(), a[2].AsString())));

        // BUG FIX: "contains" was registered in both RegisterString and RegisterCollections.
        // "indexOf" was also registered in both. The collections versions (last to run)
        // overwrote the string versions. The collections versions only handle lists, so calling
        // contains("hello", "ell") or indexOf("hello", "ell") globally would throw.
        // Fixed by making these functions handle BOTH strings and lists, registered once here.
        // RegisterCollections no longer registers contains/indexOf/reverse.
        Def(env, "contains",    2, (_, a) =>
        {
            if (a[0].Kind == ValueKind.List)
                return XeValue.FromBool(a[0].AsList().Any(v => v.XeEquals(a[1])));
            return XeValue.FromBool(a[0].AsString().Contains(a[1].AsString()));
        });
        Def(env, "startsWith",  2, (_, a) =>
            XeValue.FromBool(a[0].AsString().StartsWith(a[1].AsString())));
        Def(env, "endsWith",    2, (_, a) =>
            XeValue.FromBool(a[0].AsString().EndsWith(a[1].AsString())));
        Def(env, "indexOf",     2, (_, a) =>
        {
            if (a[0].Kind == ValueKind.List)
                return XeValue.FromDouble(a[0].AsList().FindIndex(v => v.XeEquals(a[1])));
            return XeValue.FromDouble(a[0].AsString().IndexOf(a[1].AsString()));
        });
        Def(env, "substring",   3, (_, a) =>
        {
            var s = a[0].AsString();
            int start = (int)a[1].AsNumber();
            int len   = (int)a[2].AsNumber();
            if (start < 0) start = 0;
            if (start + len > s.Length) len = s.Length - start;
            return XeValue.FromString(s.Substring(start, Math.Max(0, len)));
        });
        Def(env, "charAt",      2, (_, a) =>
        {
            var s   = a[0].AsString();
            int idx = (int)a[1].AsNumber();
            return idx >= 0 && idx < s.Length
                ? XeValue.FromString(s[idx].ToString())
                : XeValue.Nothing;
        });
        Def(env, "repeat",      2, (_, a) =>
        {
            var s = a[0].AsString();
            int n = (int)a[1].AsNumber();
            return XeValue.FromString(string.Concat(Enumerable.Repeat(s, Math.Max(0, n))));
        });
        Def(env, "format",      -1, (_, a) =>
        {
            if (a.Count == 0) return XeValue.FromString("");
            var template = a[0].AsString();
            for (int i = 1; i < a.Count; i++)
                template = template.Replace($"{{{i - 1}}}", a[i].ToDisplayString());
            return XeValue.FromString(template);
        });
        Def(env, "isBlank",     1, (_, a) =>
            XeValue.FromBool(string.IsNullOrWhiteSpace(a[0].AsString())));
        Def(env, "padLeft",     2, (_, a) =>
            XeValue.FromString(a[0].AsString().PadLeft((int)a[1].AsNumber())));
        Def(env, "padRight",    2, (_, a) =>
            XeValue.FromString(a[0].AsString().PadRight((int)a[1].AsNumber())));
    }

    // ─── Collections ──────────────────────────────────────────────────────────

    private static void RegisterCollections(XeEnvironment env)
    {
        Def(env, "list",    -1, (_, a) => XeValue.FromList(a.ToList()));
        Def(env, "count",    1, (_, a) =>
        {
            if (a[0].Kind == ValueKind.List)   return XeValue.FromDouble(a[0].AsList().Count);
            if (a[0].Kind == ValueKind.Text)    return XeValue.FromDouble(a[0].AsString().Length);
            return XeValue.FromDouble(0);
        });
        Def(env, "isEmpty",  1, (_, a) =>
        {
            if (a[0].Kind == ValueKind.List)  return XeValue.FromBool(a[0].AsList().Count == 0);
            if (a[0].Kind == ValueKind.Text)   return XeValue.FromBool(a[0].AsString().Length == 0);
            if (a[0].Kind == ValueKind.Nothing) return XeValue.True;
            return XeValue.False;
        });
        Def(env, "append",   2, (_, a) => { a[0].AsList().Add(a[1]); return XeValue.Nothing; });
        Def(env, "prepend",  2, (_, a) => { a[0].AsList().Insert(0, a[1]); return XeValue.Nothing; });
        Def(env, "removeAt", 2, (_, a) => { a[0].AsList().RemoveAt((int)a[1].AsNumber()); return XeValue.Nothing; });
        Def(env, "removeValue", 2, (_, a) =>
        {
            var lst  = a[0].AsList();
            var item = a[1];
            var idx  = lst.FindIndex(v => v.XeEquals(item));
            if (idx >= 0) lst.RemoveAt(idx);
            return XeValue.Nothing;
        });
        Def(env, "get",      2, (_, a) =>
        {
            var lst = a[0].AsList();
            int i   = (int)a[1].AsNumber();
            return i >= 0 && i < lst.Count ? lst[i] : XeValue.Nothing;
        });
        // BUG FIX: "set" was registered as a stdlib function, but "set" is a Xerox keyword.
        // The lexer converts "set" to TokenType.Set so you can never call it as a function
        // from Xerox code. Renamed to "listSet" to be accessible.
        Def(env, "listSet",  3, (_, a) =>
        {
            var lst = a[0].AsList();
            int i   = (int)a[1].AsNumber();
            if (i >= 0 && i < lst.Count) lst[i] = a[2];
            return XeValue.Nothing;
        });
        // NOTE: contains, indexOf moved to RegisterString (unified string+list versions)
        Def(env, "sort",     1, (_, a) =>
        {
            var copy = new List<XeValue>(a[0].AsList());
            copy.Sort((x, y) =>
            {
                if (x.Kind == ValueKind.Number && y.Kind == ValueKind.Number)
                    return x.AsNumber().CompareTo(y.AsNumber());
                return string.Compare(x.AsString(), y.AsString(), StringComparison.Ordinal);
            });
            return XeValue.FromList(copy);
        });
        // BUG FIX: "reverse" was registered here AND in RegisterString.
        // This version (lists only) overwrote the string version.
        // Now handles both lists and strings in one function.
        Def(env, "reverse",  1, (_, a) =>
        {
            if (a[0].Kind == ValueKind.Text)
            {
                var arr = a[0].AsString().ToCharArray();
                Array.Reverse(arr);
                return XeValue.FromString(new string(arr));
            }
            var copy = new List<XeValue>(a[0].AsList());
            copy.Reverse();
            return XeValue.FromList(copy);
        });
        Def(env, "slice",    3, (_, a) =>
        {
            var lst   = a[0].AsList();
            int start = Math.Max(0, (int)a[1].AsNumber());
            int end   = Math.Min(lst.Count, (int)a[2].AsNumber());
            return XeValue.FromList(lst.GetRange(start, Math.Max(0, end - start)));
        });
        Def(env, "concat",   2, (_, a) =>
        {
            var result = new List<XeValue>(a[0].AsList());
            result.AddRange(a[1].AsList());
            return XeValue.FromList(result);
        });
        Def(env, "first",    1, (_, a) =>
        {
            var lst = a[0].AsList();
            return lst.Count > 0 ? lst[0] : XeValue.Nothing;
        });
        Def(env, "last",     1, (_, a) =>
        {
            var lst = a[0].AsList();
            return lst.Count > 0 ? lst[^1] : XeValue.Nothing;
        });
        Def(env, "flatten",  1, (_, a) =>
        {
            var result = new List<XeValue>();
            Flatten(a[0], result);
            return XeValue.FromList(result);

            static void Flatten(XeValue v, List<XeValue> acc)
            {
                if (v.Kind == ValueKind.List)
                    foreach (var item in v.AsList()) Flatten(item, acc);
                else
                    acc.Add(v);
            }
        });
    }

    // ─── Conversions ──────────────────────────────────────────────────────────

    private static void RegisterConversions(XeEnvironment env)
    {
        Def(env, "toNumber",  1, (_, a) =>
        {
            try { return XeValue.FromDouble(a[0].AsNumber()); }
            catch { return XeValue.Nothing; }
        });
        Def(env, "toText",    1, (_, a) => XeValue.FromString(a[0].ToDisplayString()));
        Def(env, "toBool",    1, (_, a) => XeValue.FromBool(a[0].IsTruthy));
        Def(env, "isNumber",  1, (_, a) => XeValue.FromBool(a[0].Kind == ValueKind.Number));
        Def(env, "isText",    1, (_, a) => XeValue.FromBool(a[0].Kind == ValueKind.Text));
        Def(env, "isBool",    1, (_, a) => XeValue.FromBool(a[0].Kind == ValueKind.Bool));
        Def(env, "isList",    1, (_, a) => XeValue.FromBool(a[0].Kind == ValueKind.List));
        Def(env, "isObject",  1, (_, a) => XeValue.FromBool(a[0].Kind == ValueKind.Object));
        Def(env, "isNothing", 1, (_, a) => XeValue.FromBool(a[0].IsNothing));
        Def(env, "typeOf",    1, (_, a) => XeValue.FromString(a[0].Kind.ToString().ToLowerInvariant()));
    }

    // ─── System ───────────────────────────────────────────────────────────────

    private static void RegisterSystem(XeEnvironment env)
    {
        Def(env, "now", 0, (_, _) =>
            XeValue.FromString(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
        Def(env, "today", 0, (_, _) =>
            XeValue.FromString(DateTime.Today.ToString("yyyy-MM-dd")));
        Def(env, "timestamp", 0, (_, _) =>
            XeValue.FromDouble(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()));
        Def(env, "wait", 1, (_, a) =>
        {
            Thread.Sleep((int)(a[0].AsNumber() * 1000));
            return XeValue.Nothing;
        });
        Def(env, "exit", -1, (_, a) =>
        {
            int code = a.Count > 0 ? (int)a[0].AsNumber() : 0;
            Environment.Exit(code);
            return XeValue.Nothing;
        });
        Def(env, "error", 1, (_, a) =>
            throw new Errors.XeroxRuntimeException(a[0].AsString(), 0, 0));
        Def(env, "assert", 2, (_, a) =>
        {
            if (!a[0].IsTruthy)
                throw new Errors.XeroxRuntimeException($"Assertion failed: {a[1].AsString()}", 0, 0);
            return XeValue.Nothing;
        });
        Def(env, "version", 0, (_, _) => XeValue.FromString("Xerox 1.0.0"));
    }

    // ─── Registration helper ─────────────────────────────────────────────────

    private static void Def(XeEnvironment env, string name, int arity,
        Func<Interpreter.Interpreter, IReadOnlyList<XeValue>, XeValue> impl)
    {
        env.Define(name, XeValue.FromCallable(new NativeFunction(name, arity, impl)));
    }
}
