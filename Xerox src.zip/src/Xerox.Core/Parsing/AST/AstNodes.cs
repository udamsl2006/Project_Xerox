using Xerox.Core.Lexing;

namespace Xerox.Core.Parsing.AST;

// ═══════════════════════════════════════════════════════════════════════════════
//  ABSTRACT BASE NODES
// ═══════════════════════════════════════════════════════════════════════════════

/// <summary>Base for all AST nodes.  Every node carries source position.</summary>
public abstract class AstNode
{
    public Token SourceToken { get; init; } = null!;
}

/// <summary>A node that produces a value.</summary>
public abstract class Expression : AstNode { }

/// <summary>A node that performs an action.</summary>
public abstract class Statement : AstNode { }

// ═══════════════════════════════════════════════════════════════════════════════
//  EXPRESSIONS
// ═══════════════════════════════════════════════════════════════════════════════

/// <summary> 42 | 3.14 | "hello" | true | false | nothing </summary>
public sealed class LiteralExpr : Expression
{
    public object? Value { get; init; }
}

/// <summary> x | name | count </summary>
public sealed class VariableExpr : Expression
{
    public string Name { get; init; } = "";
}

/// <summary> itself  (self reference inside a blueprint) </summary>
public sealed class SelfExpr : Expression { }

/// <summary> a plus b | a joined with b | a is greater than b … </summary>
public sealed class BinaryExpr : Expression
{
    public Expression Left     { get; init; } = null!;
    public BinaryOp   Operator { get; init; }
    public Expression Right    { get; init; } = null!;
}

/// <summary> not x | minus x </summary>
public sealed class UnaryExpr : Expression
{
    public UnaryOp    Operator { get; init; }
    public Expression Operand  { get; init; } = null!;
}

/// <summary> call greet with "Alice", 42 </summary>
public sealed class CallExpr : Expression
{
    public Expression            Callee    { get; init; } = null!;   // VariableExpr or MemberExpr
    public IReadOnlyList<Expression> Args  { get; init; } = Array.Empty<Expression>();
}

/// <summary> person.name </summary>
public sealed class MemberAccessExpr : Expression
{
    public Expression Object  { get; init; } = null!;
    public string     Member  { get; init; } = "";
}

/// <summary> myList at index 2 </summary>
public sealed class IndexExpr : Expression
{
    public Expression Collection { get; init; } = null!;
    public Expression IndexValue { get; init; } = null!;
}

/// <summary> new Dog with name "Rex", age 3 </summary>
public sealed class NewObjectExpr : Expression
{
    public string                    BlueprintName { get; init; } = "";
    public IReadOnlyList<Expression> Args          { get; init; } = Array.Empty<Expression>();
}

/// <summary> [1, 2, 3] </summary>
public sealed class ListLiteralExpr : Expression
{
    public IReadOnlyList<Expression> Items { get; init; } = Array.Empty<Expression>();
}

/// <summary> length of myText </summary>
public sealed class LengthExpr : Expression
{
    public Expression Target { get; init; } = null!;
}

/// <summary> count of myList </summary>
public sealed class CountExpr : Expression
{
    public Expression Collection { get; init; } = null!;
}

/// <summary> absolute of x | round of x | floor of x | ceiling of x | squareroot of x </summary>
public sealed class BuiltinMathExpr : Expression
{
    public BuiltinMathOp Op     { get; init; }
    public Expression    Target { get; init; } = null!;
}

/// <summary> x power y | random from a to b </summary>
public sealed class BuiltinMath2Expr : Expression
{
    public BuiltinMath2Op Op    { get; init; }
    public Expression     Left  { get; init; } = null!;
    public Expression     Right { get; init; } = null!;
}


/// <summary> x = expr  (assignment expression, returns the assigned value) </summary>
public sealed class AssignExpr : Expression
{
    public Expression Target { get; init; } = null!;
    public Expression Value  { get; init; } = null!;
}
/// <summary> ask "What is your name?" </summary>
public sealed class AskExpr : Expression
{
    public Expression Prompt { get; init; } = null!;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  STATEMENTS
// ═══════════════════════════════════════════════════════════════════════════════

/// <summary> A list of statements executed in order. </summary>
public sealed class BlockStmt : Statement
{
    public IReadOnlyList<Statement> Statements { get; init; } = Array.Empty<Statement>();
}

/// <summary> create number x with value 10 </summary>
public sealed class VarDeclStmt : Statement
{
    public string     Name     { get; init; } = "";
    public string?    TypeHint { get; init; }          // optional type annotation
    public Expression? Value   { get; init; }           // optional initialiser
}

/// <summary> set x to 42  |  x = 42  |  person.name = "Alice" </summary>
public sealed class AssignStmt : Statement
{
    public Expression Target { get; init; } = null!;   // VariableExpr | MemberAccessExpr | IndexExpr
    public Expression Value  { get; init; } = null!;
}

/// <summary> display "Hello" </summary>
public sealed class DisplayStmt : Statement
{
    public IReadOnlyList<Expression> Values { get; init; } = Array.Empty<Expression>();
}

/// <summary> return x  |  give back x </summary>
public sealed class ReturnStmt : Statement
{
    public Expression? Value { get; init; }
}

/// <summary> break </summary>
public sealed class BreakStmt : Statement { }

/// <summary> continue / skip </summary>
public sealed class ContinueStmt : Statement { }

/// <summary>
/// if &lt;cond&gt; then … [otherwise …] end if
/// </summary>
public sealed class IfStmt : Statement
{
    public Expression             Condition   { get; init; } = null!;
    public BlockStmt              ThenBranch  { get; init; } = null!;
    public IReadOnlyList<(Expression, BlockStmt)> ElseIfs { get; init; }
        = Array.Empty<(Expression, BlockStmt)>();
    public BlockStmt?             ElseBranch  { get; init; }
}

/// <summary> while &lt;cond&gt; … end while </summary>
public sealed class WhileStmt : Statement
{
    public Expression Condition { get; init; } = null!;
    public BlockStmt  Body      { get; init; } = null!;
}

/// <summary> repeat 5 times … end repeat </summary>
public sealed class RepeatStmt : Statement
{
    public Expression Count { get; init; } = null!;
    public BlockStmt  Body  { get; init; } = null!;
}

/// <summary> for each item in myList … end for </summary>
public sealed class ForEachStmt : Statement
{
    public string     Variable   { get; init; } = "";
    public Expression Collection { get; init; } = null!;
    public BlockStmt  Body       { get; init; } = null!;
}

/// <summary>
/// define function greet that takes name
///     …
/// end function
/// </summary>
public sealed class FunctionDeclStmt : Statement
{
    public string                    Name       { get; init; } = "";
    public IReadOnlyList<Parameter>  Params     { get; init; } = Array.Empty<Parameter>();
    public string?                   ReturnType { get; init; }
    public BlockStmt                 Body       { get; init; } = null!;
    public bool                      IsMethod   { get; init; }
}

/// <summary> A function parameter: name [as type] [= default] </summary>
public sealed class Parameter
{
    public string     Name         { get; init; } = "";
    public string?    TypeHint     { get; init; }
    public Expression? Default     { get; init; }
}

/// <summary>
/// blueprint Animal has name, age
///     knows how to speak … end function
///     build with name … end build
/// end blueprint
/// </summary>
public sealed class BlueprintDeclStmt : Statement
{
    public string                         Name        { get; init; } = "";
    public string?                        Parent      { get; init; }   // extend Animal from Creature
    public IReadOnlyList<FieldDecl>       Fields      { get; init; } = Array.Empty<FieldDecl>();
    public FunctionDeclStmt?              Constructor { get; init; }
    public IReadOnlyList<FunctionDeclStmt> Methods    { get; init; } = Array.Empty<FunctionDeclStmt>();
}

/// <summary> A field declared in a blueprint: name [as type] [with value expr] </summary>
public sealed class FieldDecl
{
    public string     Name     { get; init; } = "";
    public string?    TypeHint { get; init; }
    public Expression? Default { get; init; }
    public Token      Token    { get; init; } = null!;
}

/// <summary>
/// Bare expression used as a statement (function calls, etc.)
/// </summary>
public sealed class ExpressionStmt : Statement
{
    public Expression Expr { get; init; } = null!;
}

/// <summary> add value to list </summary>
public sealed class ListAddStmt : Statement
{
    public Expression Value { get; init; } = null!;
    public Expression List  { get; init; } = null!;
}

/// <summary> remove value from list  |  remove at index n from list </summary>
public sealed class ListRemoveStmt : Statement
{
    public Expression  List    { get; init; } = null!;
    public Expression? Value   { get; init; }   // remove by value
    public Expression? AtIndex { get; init; }   // remove at index
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PROGRAM ROOT
// ═══════════════════════════════════════════════════════════════════════════════

public sealed class ProgramNode : AstNode
{
    public IReadOnlyList<Statement> Statements { get; init; } = Array.Empty<Statement>();
    public string SourceFile { get; init; } = "<input>";
}

// ═══════════════════════════════════════════════════════════════════════════════
//  OPERATOR ENUMS
// ═══════════════════════════════════════════════════════════════════════════════

public enum BinaryOp
{
    // arithmetic
    Add, Subtract, Multiply, Divide, Modulo,
    // comparison
    Equal, NotEqual, Less, LessOrEqual, Greater, GreaterOrEqual,
    // logical
    And, Or,
    // string
    Concat,
    // containment
    Contains, StartsWith, EndsWith,
}

public enum UnaryOp { Negate, Not }

public enum BuiltinMathOp  { Absolute, Round, Floor, Ceiling, Sqrt }
public enum BuiltinMath2Op { Power, Random }