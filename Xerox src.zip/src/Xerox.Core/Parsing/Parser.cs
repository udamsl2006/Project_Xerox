using Xerox.Core.Errors;
using Xerox.Core.Lexing;
using Xerox.Core.Parsing.AST;

namespace Xerox.Core.Parsing;

/// <summary>
/// Recursive-descent parser for the Xerox language.
/// Converts a token stream into a typed AST.
/// </summary>
public sealed class Parser
{
    private readonly IReadOnlyList<Token> _tokens;
    private readonly List<XeroxError>     _errors = new();
    private int _pos = 0;

    private Parser(IReadOnlyList<Token> tokens) => _tokens = tokens;

    public static ParseResult Parse(IReadOnlyList<Token> tokens, string file = "<input>")
    {
        var p = new Parser(tokens);
        var program = p.ParseProgram(file);
        return new ParseResult(program, p._errors);
    }

    // ─── Program ──────────────────────────────────────────────────────────────

    private ProgramNode ParseProgram(string file)
    {
        var stmts = new List<Statement>();
        SkipNewlines();
        var tok = Current();
        while (!IsAtEnd())
        {
            try
            {
                var s = ParseStatement();
                if (s is not null) stmts.Add(s);
            }
            catch (ParseException ex)
            {
                foreach (var e in ex.Errors) _errors.Add(e);
                Synchronize();
            }
            SkipNewlines();
        }
        return new ProgramNode { Statements = stmts, SourceFile = file, SourceToken = tok };
    }

    // ─── Statements ───────────────────────────────────────────────────────────

    private Statement ParseStatement()
    {
        var cur = Current();
        return cur.Type switch
        {
            TokenType.Create    => ParseVarDecl(),
            TokenType.Set       => ParseAssignSet(),
            TokenType.Let       => ParseAssignSet(),
            TokenType.Display   => ParseDisplay(),
            TokenType.Return    => ParseReturn(),
            TokenType.Give      => ParseGiveBack(),
            TokenType.Break     => ParseBreak(),
            TokenType.Continue  => ParseContinue(),
            TokenType.Skip      => ParseContinue(),
            TokenType.If        => ParseIf(),
            TokenType.While     => ParseWhile(),
            TokenType.Repeat    => ParseRepeat(),
            TokenType.For       => ParseForEach(),
            TokenType.Define    => ParseFunctionDecl(),
            TokenType.Blueprint => ParseBlueprintDecl(),
            TokenType.Add       => ParseListAdd(),
            TokenType.Remove    => ParseListRemove(),
            _                   => ParseExpressionStatement()
        };
    }

    // create [type] name [with value expr]
    private VarDeclStmt ParseVarDecl()
    {
        var tok = Consume(TokenType.Create, "Expected 'create'.");
        string? typeHint = TryConsumeTypeHint();
        string name = ConsumeAnyName("Expected variable name after 'create'.").Lexeme;

        Expression? value = null;
        if (Match(TokenType.With))
        {
            TryConsume(TokenType.Value);
            value = ParseExpression();
        }
        else if (Match(TokenType.SymEqual))
        {
            value = ParseExpression();
        }
        ExpectNewlineOrEof();
        return new VarDeclStmt { Name = name, TypeHint = typeHint, Value = value, SourceToken = tok };
    }

    // set x to expr  |  let x = expr
    private AssignStmt ParseAssignSet()
    {
        var tok = Advance(); // consume 'set' or 'let'
        var target = ParseAssignTarget();
        if (tok.Type == TokenType.Set)
        {
            if (!Match(TokenType.To) && !Match(TokenType.SymEqual))
                Error(Current(), "Expected 'to' or '=' after variable name in 'set'.");
        }
        else // let
        {
            if (!Match(TokenType.SymEqual))
                Error(Current(), "Expected '=' after variable name in 'let'.");
        }
        var value = ParseExpression();
        ExpectNewlineOrEof();
        return new AssignStmt { Target = target, Value = value, SourceToken = tok };
    }

    // display expr [, expr]*
    private DisplayStmt ParseDisplay()
    {
        var tok = Consume(TokenType.Display, "Expected 'display'.");
        var values = new List<Expression> { ParseExpression() };
        while (Match(TokenType.Comma) || Match(TokenType.And))
            values.Add(ParseExpression());
        ExpectNewlineOrEof();
        return new DisplayStmt { Values = values, SourceToken = tok };
    }

    // return [expr]  |  give back [expr]
    private ReturnStmt ParseReturn()
    {
        var tok = Consume(TokenType.Return, "Expected 'return'.");
        Expression? value = null;
        if (!IsAtNewlineOrEof()) value = ParseExpression();
        ExpectNewlineOrEof();
        return new ReturnStmt { Value = value, SourceToken = tok };
    }

    private ReturnStmt ParseGiveBack()
    {
        var tok = Consume(TokenType.Give, "Expected 'give'.");
        Consume(TokenType.Back, "Expected 'back' after 'give'.");
        Expression? value = null;
        if (!IsAtNewlineOrEof()) value = ParseExpression();
        ExpectNewlineOrEof();
        return new ReturnStmt { Value = value, SourceToken = tok };
    }

    private BreakStmt ParseBreak()
    {
        var tok = Advance();
        ExpectNewlineOrEof();
        return new BreakStmt { SourceToken = tok };
    }

    private ContinueStmt ParseContinue()
    {
        var tok = Advance();
        ExpectNewlineOrEof();
        return new ContinueStmt { SourceToken = tok };
    }

    // if <cond> then
    //   …
    // [otherwise if <cond> then …]
    // [otherwise …]
    // end if
    private IfStmt ParseIf()
    {
        var tok = Consume(TokenType.If, "Expected 'if'.");
        var cond = ParseExpression();
        TryConsume(TokenType.Then);
        ExpectNewlineOrEof();

        var thenBlock = ParseBlockUntil(TokenType.Otherwise, TokenType.End);

        var elseIfs = new List<(Expression, BlockStmt)>();
        BlockStmt? elseBlock = null;

        while (Check(TokenType.Otherwise))
        {
            Advance(); // 'otherwise'
            if (Check(TokenType.If))
            {
                Advance(); // 'if'
                var eicond = ParseExpression();
                TryConsume(TokenType.Then);
                ExpectNewlineOrEof();
                var eibody = ParseBlockUntil(TokenType.Otherwise, TokenType.End);
                elseIfs.Add((eicond, eibody));
            }
            else
            {
                ExpectNewlineOrEof();
                elseBlock = ParseBlockUntil(TokenType.End);
                break;
            }
        }

        ConsumeEnd("if");
        ExpectNewlineOrEof();
        return new IfStmt
        {
            Condition = cond, ThenBranch = thenBlock,
            ElseIfs = elseIfs, ElseBranch = elseBlock,
            SourceToken = tok
        };
    }

    // while <cond> … end while
    private WhileStmt ParseWhile()
    {
        var tok = Consume(TokenType.While, "Expected 'while'.");
        var cond = ParseExpression();
        ExpectNewlineOrEof();
        var body = ParseBlockUntil(TokenType.End);
        ConsumeEnd("while");
        ExpectNewlineOrEof();
        return new WhileStmt { Condition = cond, Body = body, SourceToken = tok };
    }

    // repeat <expr> times … end repeat
    private RepeatStmt ParseRepeat()
    {
        var tok = Consume(TokenType.Repeat, "Expected 'repeat'.");
        var count = ParseRepeatCount();
        TryConsume(TokenType.Times);
        ExpectNewlineOrEof();
        var body = ParseBlockUntil(TokenType.End);
        ConsumeEnd("repeat");
        ExpectNewlineOrEof();
        return new RepeatStmt { Count = count, Body = body, SourceToken = tok };
    }

    // for each <var> in <collection> … end for
    private ForEachStmt ParseForEach()
    {
        var tok = Consume(TokenType.For, "Expected 'for'.");
        Consume(TokenType.Each, "Expected 'each' after 'for'.");
        string varName = ConsumeAnyName("Expected variable name.").Lexeme;
        Consume(TokenType.In, "Expected 'in' after loop variable.");
        var collection = ParseExpression();
        ExpectNewlineOrEof();
        var body = ParseBlockUntil(TokenType.End);
        ConsumeEnd("for");
        ExpectNewlineOrEof();
        return new ForEachStmt { Variable = varName, Collection = collection, Body = body, SourceToken = tok };
    }

    // define function <name> [that takes <params>] [returns <type>]
    //   …
    // end function
    private FunctionDeclStmt ParseFunctionDecl(bool isMethod = false)
    {
        var tok = Consume(TokenType.Define, "Expected 'define'.");
        TryConsume(TokenType.Function);
        string name = ConsumeAnyName("Expected function name.").Lexeme;

        var parms = new List<Parameter>();
        if (Match(TokenType.That))
        {
            TryConsume(TokenType.Takes);
            TryConsumeIdentifier("accepts");
            parms = ParseParameterList();
        }

        string? returnType = null;
        if (Match(TokenType.Returns))
            returnType = ConsumeAnyName("Expected return type.").Lexeme;

        ExpectNewlineOrEof();
        var body = ParseBlockUntil(TokenType.End);
        ConsumeEnd("function");
        ExpectNewlineOrEof();

        return new FunctionDeclStmt
        {
            Name = name, Params = parms, ReturnType = returnType,
            Body = body, IsMethod = isMethod, SourceToken = tok
        };
    }

    // blueprint <name> [extends <parent>]
    //     has <fields>
    //     [build with … end build]
    //     [knows how to <method> … end function]*
    // end blueprint
    private BlueprintDeclStmt ParseBlueprintDecl()
    {
        var tok = Consume(TokenType.Blueprint, "Expected 'blueprint'.");
        string name = ConsumeAnyName("Expected blueprint name.").Lexeme;

        string? parent = null;
        if (Match(TokenType.Extend))
        {
            TryConsume(TokenType.From);
            if (CheckAnyName())
                parent = Advance().Lexeme;
        }
        else if (Match(TokenType.From))
        {
            if (CheckAnyName())
                parent = Advance().Lexeme;
        }

        ExpectNewlineOrEof();
        SkipNewlines();

        var fields      = new List<FieldDecl>();
        FunctionDeclStmt? ctor = null;
        var methods     = new List<FunctionDeclStmt>();

        while (!IsAtEnd() && !(Check(TokenType.End) && PeekIs(1, "blueprint")))
        {
            SkipNewlines();
            if (IsAtEnd()) break;

            if (Check(TokenType.End) && PeekIs(1, "blueprint")) break;

            var cur = Current();
            if (cur.Type == TokenType.Has)
            {
                fields.AddRange(ParseFieldDeclarations());
            }
            else if (cur.Type == TokenType.Build)
            {
                ctor = ParseConstructor();
            }
            else if (cur.Type == TokenType.Knows)
            {
                methods.Add(ParseMethod());
            }
            else if (cur.Type == TokenType.Define)
            {
                methods.Add(ParseFunctionDecl(isMethod: true));
            }
            else
            {
                Error(cur, $"Unexpected token '{cur.Lexeme}' inside blueprint.");
                Synchronize();
            }
            SkipNewlines();
        }

        ConsumeEnd("blueprint");
        ExpectNewlineOrEof();

        return new BlueprintDeclStmt
        {
            Name = name, Parent = parent,
            Fields = fields, Constructor = ctor, Methods = methods,
            SourceToken = tok
        };
    }

    // has name [as type] [with value expr], age [as type], …
    private List<FieldDecl> ParseFieldDeclarations()
    {
        Consume(TokenType.Has, "Expected 'has'.");
        var fields = new List<FieldDecl>();
        do
        {
            TryConsume(TokenType.Comma);
            var ftok = Current();
            string fname = ConsumeAnyName("Expected field name.").Lexeme;
            string? ftype = null;
            if (Match(TokenType.As)) ftype = ConsumeTypeName();
            Expression? fdefault = null;
            if (Match(TokenType.With)) { TryConsume(TokenType.Value); fdefault = ParseExpression(); }
            fields.Add(new FieldDecl { Name = fname, TypeHint = ftype, Default = fdefault, Token = ftok });
        } while (Check(TokenType.Comma) || (Check(TokenType.And) && !IsControlFlowNext()));

        ExpectNewlineOrEof();
        return fields;
    }

    // build with <params> … end build
    private FunctionDeclStmt ParseConstructor()
    {
        var tok = Consume(TokenType.Build, "Expected 'build'.");
        TryConsume(TokenType.With);
        var parms = ParseParameterList();
        ExpectNewlineOrEof();
        var body = ParseBlockUntil(TokenType.End);
        // consume 'end build' or 'end constructor'
        Consume(TokenType.End, "Expected 'end' to close constructor.");
        TryConsume(TokenType.Build);  // "end build" or "end constructor" (both lex as Build)
        ExpectNewlineOrEof();
        return new FunctionDeclStmt
        {
            Name = "#constructor", Params = parms,
            Body = body, IsMethod = true, SourceToken = tok
        };
    }

    // knows how to <name> [that takes <params>] … end function
    private FunctionDeclStmt ParseMethod()
    {
        var tok = Consume(TokenType.Knows, "Expected 'knows'.");
        TryConsume(TokenType.How);
        TryConsume(TokenType.To);
        string name = ConsumeAnyName("Expected method name.").Lexeme;

        var parms = new List<Parameter>();
        if (Match(TokenType.That))
        {
            TryConsume(TokenType.Takes);
            parms = ParseParameterList();
        }

        string? returnType = null;
        if (Match(TokenType.Returns))
            returnType = ConsumeAnyName("Expected return type.").Lexeme;

        ExpectNewlineOrEof();
        var body = ParseBlockUntil(TokenType.End);
        ConsumeEnd("function");
        ExpectNewlineOrEof();

        return new FunctionDeclStmt
        {
            Name = name, Params = parms, ReturnType = returnType,
            Body = body, IsMethod = true, SourceToken = tok
        };
    }

    // add <expr> to <list-expr>
    private ListAddStmt ParseListAdd()
    {
        var tok = Consume(TokenType.Add, "Expected 'add'.");
        var value = ParseExpression();
        Consume(TokenType.To, "Expected 'to' after value in 'add'.");
        var list = ParseExpression();
        ExpectNewlineOrEof();
        return new ListAddStmt { Value = value, List = list, SourceToken = tok };
    }

    // remove <expr> from <list>  |  remove at index <n> from <list>
    private ListRemoveStmt ParseListRemove()
    {
        var tok = Consume(TokenType.Remove, "Expected 'remove'.");
        Expression? atIdx = null;
        Expression? value = null;
        if (Match(TokenType.At))
        {
            TryConsume(TokenType.Index);
            atIdx = ParseExpression();
        }
        else
        {
            value = ParseExpression();
        }
        Consume(TokenType.From, "Expected 'from' after value in 'remove'.");
        var list = ParseExpression();
        ExpectNewlineOrEof();
        return new ListRemoveStmt { List = list, Value = value, AtIndex = atIdx, SourceToken = tok };
    }

    private Statement ParseExpressionStatement()
    {
        var tok = Current();
        // Detect bare assignment: identifier [.member]* = expr  (e.g. x = 5, obj.field = 5)
        if (CheckAnyName())
        {
            int saved = _pos;
            var target = TryParseAssignTarget();
            if (target is not null && Match(TokenType.SymEqual))
            {
                var value = ParseExpression();
                ExpectNewlineOrEof();
                return new AssignStmt { Target = target, Value = value, SourceToken = tok };
            }
            _pos = saved; // backtrack
        }
        var expr = ParseExpression();
        ExpectNewlineOrEof();
        return new ExpressionStmt { Expr = expr, SourceToken = tok };
    }

    // Attempt to parse an assignment target (identifier [.member]* [at index expr]).
    // Returns null if current position doesn't look like a valid target.
    private Expression? TryParseAssignTarget()
    {
        if (!CheckAnyName()) return null;
        var identTok = Advance();
        Expression expr = new VariableExpr { Name = identTok.Lexeme, SourceToken = identTok };
        while (Match(TokenType.Dot))
        {
            if (!CheckAnyName()) return null;
            var member = Advance().Lexeme;
            expr = new MemberAccessExpr { Object = expr, Member = member, SourceToken = Previous() };
        }
        if (Check(TokenType.At))
        {
            var at = Advance(); TryConsume(TokenType.Index);
            var idx = ParseExpression();
            expr = new IndexExpr { Collection = expr, IndexValue = idx, SourceToken = at };
        }
        return expr;
    }

    // ─── Parameter parsing ────────────────────────────────────────────────────

    private List<Parameter> ParseParameterList()
    {
        var parms = new List<Parameter>();
        if (!CheckAnyName()) return parms;

        do
        {
            TryConsume(TokenType.Comma); TryConsume(TokenType.And);
            if (!CheckAnyName()) break;
            string pname = Advance().Lexeme;
            string? ptype = null;
            if (Match(TokenType.As)) ptype = ConsumeTypeName();
            Expression? pdefault = null;
            if (Match(TokenType.With)) { TryConsume(TokenType.Value); pdefault = ParseExpression(); }
            parms.Add(new Parameter { Name = pname, TypeHint = ptype, Default = pdefault });
        }
        while ((Check(TokenType.Comma) || Check(TokenType.And)) && !IsControlFlowNext());

        return parms;
    }


    // Consume any token that can serve as a name (identifier or keyword used as name)
    private Token ConsumeAnyName(string errorMsg)
    {
        if (IsAtEnd()) { Error(Current(), errorMsg); }
        var tok = Current();
        // Accept Identifier tokens OR keyword tokens whose lexeme looks like an identifier
        // (i.e., only alphabetic/alphanumeric — not operators or punctuation)
        if (tok.Lexeme.Length > 0 && char.IsLetter(tok.Lexeme[0]))
        {
            Advance();
            return tok;
        }
        Error(tok, errorMsg);
        return tok; // unreachable
    }

    private bool CheckAnyName()
    {
        if (IsAtEnd()) return false;
        var tok = Current();
        return tok.Lexeme.Length > 0 && char.IsLetter(tok.Lexeme[0]);
    }

    // ─── Expressions ──────────────────────────────────────────────────────────

    private Expression ParseExpression()
    {
        var expr = ParseOr();
        // Assignment expression: target = value  (e.g. inside parens or short-circuit)
        if (Check(TokenType.SymEqual) && IsValidAssignTarget(expr))
        {
            var eqTok = Advance(); // consume = or to
            var value = ParseOr();
            return new AssignExpr { Target = expr, Value = value, SourceToken = eqTok };
        }
        return expr;
    }

    private static bool IsValidAssignTarget(Expression expr) =>
        expr is VariableExpr or MemberAccessExpr or IndexExpr;

    // Parse the count expression in 'repeat N times' - stops before 'times' keyword
    private Expression ParseRepeatCount()
    {
        // Use ParseUnary to avoid consuming 'times' as multiplication operator
        return ParseUnary();
    }

    private Expression ParseOr()
    {
        var left = ParseAnd();
        while (Check(TokenType.Or) || Check(TokenType.SymPipePipe))
        {
            var op = Advance();
            var right = ParseAnd();
            left = new BinaryExpr { Left = left, Operator = BinaryOp.Or, Right = right, SourceToken = op };
        }
        return left;
    }

    private Expression ParseAnd()
    {
        var left = ParseNot();
        while ((Check(TokenType.And) && !IsParameterContext()) || Check(TokenType.SymAmpAmp)
               || Check(TokenType.Both))
        {
            var op = Advance();
            if (op.Type == TokenType.Both) TryConsume(TokenType.And);
            var right = ParseNot();
            left = new BinaryExpr { Left = left, Operator = BinaryOp.And, Right = right, SourceToken = op };
        }
        return left;
    }

    private Expression ParseNot()
    {
        if (Check(TokenType.Not) || Check(TokenType.SymBang))
        {
            var op = Advance();
            return new UnaryExpr { Operator = UnaryOp.Not, Operand = ParseNot(), SourceToken = op };
        }
        return ParseComparison();
    }

    // Handle English comparison chains: x is greater than y
    private Expression ParseComparison()
    {
        var left = ParseAddSub();

        // "is [not] greater/less/equal than/to …" chain
        if (Check(TokenType.Is))
        {
            var isTok = Advance(); // consume 'is'
            bool negate = Match(TokenType.Not);

            BinaryOp op;
            if (Check(TokenType.Greater))
            {
                Advance(); TryConsume(TokenType.Than);
                op = negate ? BinaryOp.LessOrEqual : BinaryOp.Greater;
            }
            else if (Check(TokenType.Less))
            {
                Advance(); TryConsume(TokenType.Than);
                op = negate ? BinaryOp.GreaterOrEqual : BinaryOp.Less;
            }
            else if (Check(TokenType.Equal) || Check(TokenType.SymEqualEqual))
            {
                Advance(); TryConsume(TokenType.To);
                op = negate ? BinaryOp.NotEqual : BinaryOp.Equal;
            }
            else if (Check(TokenType.Nothing))
            {
                Advance();
                op = negate ? BinaryOp.NotEqual : BinaryOp.Equal;
                var nullLit = new LiteralExpr { Value = null, SourceToken = Previous() };
                return new BinaryExpr { Left = left, Operator = op, Right = nullLit, SourceToken = isTok };
            }
            else
            {
                // x is y  → equality check
                op = negate ? BinaryOp.NotEqual : BinaryOp.Equal;
            }

            var right = ParseAddSub();
            left = new BinaryExpr { Left = left, Operator = op, Right = right, SourceToken = isTok };
        }
        else if (Check(TokenType.Contains))
        {
            var op2 = Advance();
            var right = ParseAddSub();
            left = new BinaryExpr { Left = left, Operator = BinaryOp.Contains, Right = right, SourceToken = op2 };
        }
        else if (Check(TokenType.Starts))
        {
            var op2 = Advance(); TryConsume(TokenType.With);
            var right = ParseAddSub();
            left = new BinaryExpr { Left = left, Operator = BinaryOp.StartsWith, Right = right, SourceToken = op2 };
        }
        else if (Check(TokenType.Ends))
        {
            var op2 = Advance(); TryConsume(TokenType.With);
            var right = ParseAddSub();
            left = new BinaryExpr { Left = left, Operator = BinaryOp.EndsWith, Right = right, SourceToken = op2 };
        }
        // symbolic comparison operators
        else if (Check(TokenType.SymEqualEqual) || Check(TokenType.SymNotEqual) ||
                 Check(TokenType.SymLt) || Check(TokenType.SymLte) ||
                 Check(TokenType.SymGt) || Check(TokenType.SymGte))
        {
            var opTok = Advance();
            var op = opTok.Type switch
            {
                TokenType.SymEqualEqual => BinaryOp.Equal,
                TokenType.SymNotEqual   => BinaryOp.NotEqual,
                TokenType.SymLt         => BinaryOp.Less,
                TokenType.SymLte        => BinaryOp.LessOrEqual,
                TokenType.SymGt         => BinaryOp.Greater,
                _                       => BinaryOp.GreaterOrEqual,
            };
            var right = ParseAddSub();
            left = new BinaryExpr { Left = left, Operator = op, Right = right, SourceToken = opTok };
        }

        return left;
    }

    private Expression ParseAddSub()
    {
        var left = ParseMulDiv();
        while (true)
        {
            if (Check(TokenType.Plus) || Check(TokenType.SymPlus))
            {
                var op = Advance();
                var right = ParseMulDiv();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Add, Right = right, SourceToken = op };
            }
            else if (Check(TokenType.Minus) || Check(TokenType.SymMinus))
            {
                var op = Advance();
                var right = ParseMulDiv();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Subtract, Right = right, SourceToken = op };
            }
            else if (Check(TokenType.Joined))
            {
                var op = Advance(); TryConsume(TokenType.With);
                var right = ParseMulDiv();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Concat, Right = right, SourceToken = op };
            }
            else break;
        }
        return left;
    }

    private Expression ParseMulDiv()
    {
        var left = ParseUnary();
        while (true)
        {
            if (Check(TokenType.Times2) || Check(TokenType.SymStar))
            {
                var op = Advance(); TryConsume(TokenType.By);
                var right = ParseUnary();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Multiply, Right = right, SourceToken = op };
            }
            else if (Check(TokenType.Divided))
            {
                var op = Advance(); TryConsume(TokenType.By);
                var right = ParseUnary();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Divide, Right = right, SourceToken = op };
            }
            else if (Check(TokenType.Modulo) || Check(TokenType.SymPercent))
            {
                var op = Advance(); TryConsume(TokenType.By);
                var right = ParseUnary();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Modulo, Right = right, SourceToken = op };
            }
            else if (Check(TokenType.SymSlash))
            {
                var op = Advance();
                var right = ParseUnary();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Divide, Right = right, SourceToken = op };
            }
            else if (Check(TokenType.Times) && !IsTimesInRepeat())
            {
                var op = Advance();
                var right = ParseUnary();
                left = new BinaryExpr { Left = left, Operator = BinaryOp.Multiply, Right = right, SourceToken = op };
            }
            else break;
        }
        return left;
    }

    private Expression ParseUnary()
    {
        if (Check(TokenType.Minus) || Check(TokenType.SymMinus))
        {
            var op = Advance();
            return new UnaryExpr { Operator = UnaryOp.Negate, Operand = ParseUnary(), SourceToken = op };
        }
        if (Check(TokenType.Not) || Check(TokenType.SymBang))
        {
            var op = Advance();
            return new UnaryExpr { Operator = UnaryOp.Not, Operand = ParseUnary(), SourceToken = op };
        }

        // builtin math
        if (Check(TokenType.Absolute)) { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new BuiltinMathExpr { Op = BuiltinMathOp.Absolute, Target = x, SourceToken = t }; }
        if (Check(TokenType.Round))    { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new BuiltinMathExpr { Op = BuiltinMathOp.Round,    Target = x, SourceToken = t }; }
        if (Check(TokenType.Floor))    { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new BuiltinMathExpr { Op = BuiltinMathOp.Floor,    Target = x, SourceToken = t }; }
        if (Check(TokenType.Ceiling))  { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new BuiltinMathExpr { Op = BuiltinMathOp.Ceiling,  Target = x, SourceToken = t }; }
        if (Check(TokenType.Sqrt))     { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new BuiltinMathExpr { Op = BuiltinMathOp.Sqrt,     Target = x, SourceToken = t }; }
        if (Check(TokenType.Length))   { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new LengthExpr { Target = x, SourceToken = t }; }
        if (Check(TokenType.Count))    { var t = Advance(); TryConsume(TokenType.Of); var x = ParseUnary(); return new CountExpr { Collection = x, SourceToken = t }; }

        if (Check(TokenType.Power))
        {
            var t = Advance(); TryConsume(TokenType.Of);
            var b = ParseUnary(); TryConsume(TokenType.To); TryConsumeIdentifier("the"); var e = ParseUnary();
            return new BuiltinMath2Expr { Op = BuiltinMath2Op.Power, Left = b, Right = e, SourceToken = t };
        }
        if (Check(TokenType.Random))
        {
            var t = Advance();
            if (Match(TokenType.From))
            {
                var lo = ParseUnary(); TryConsume(TokenType.To); var hi = ParseUnary();
                return new BuiltinMath2Expr { Op = BuiltinMath2Op.Random, Left = lo, Right = hi, SourceToken = t };
            }
            return new BuiltinMath2Expr { Op = BuiltinMath2Op.Random, Left = new LiteralExpr { Value = 0.0, SourceToken = t }, Right = new LiteralExpr { Value = 1.0, SourceToken = t }, SourceToken = t };
        }
        if (Check(TokenType.Ask))
        {
            var t = Advance(); var prompt = ParseUnary();
            return new AskExpr { Prompt = prompt, SourceToken = t };
        }

        return ParsePostfix();
    }

    private Expression ParsePostfix()
    {
        var expr = ParsePrimary();
        while (true)
        {
            if (Check(TokenType.Dot))
            {
                var dot = Advance();
                string member = ConsumeAnyName("Expected member name after '.'.").Lexeme;
                expr = new MemberAccessExpr { Object = expr, Member = member, SourceToken = dot };

                // method call: obj.method with arg1, arg2
                if (Match(TokenType.With) || Check(TokenType.LeftParen))
                {
                    var args = ParseArgList();
                    expr = new CallExpr { Callee = expr, Args = args, SourceToken = dot };
                }
            }
            else if (Check(TokenType.At))
            {
                var at = Advance(); TryConsume(TokenType.Index);
                // Use ParseAddSub so "arr at index i plus 1" parses as arr[i+1] not arr[i]+1
                var idx = ParseAddSub();
                expr = new IndexExpr { Collection = expr, IndexValue = idx, SourceToken = at };
            }
            else if (Check(TokenType.LeftParen))
            {
                var paren = Advance();
                var args  = new List<Expression>();
                if (!Check(TokenType.RightParen))
                {
                    args.Add(ParseExpression());
                    while (Match(TokenType.Comma)) args.Add(ParseExpression());
                }
                Consume(TokenType.RightParen, "Expected ')' after arguments.");
                expr = new CallExpr { Callee = expr, Args = args, SourceToken = paren };
            }
            else break;
        }
        return expr;
    }

    private Expression ParsePrimary()
    {
        var tok = Current();

        // literals
        if (Match(TokenType.Number))  return new LiteralExpr { Value = Previous().Literal, SourceToken = Previous() };
        if (Match(TokenType.Text))    return new LiteralExpr { Value = Previous().Literal, SourceToken = Previous() };
        if (Match(TokenType.True))    return new LiteralExpr { Value = true,  SourceToken = Previous() };
        if (Match(TokenType.False))   return new LiteralExpr { Value = false, SourceToken = Previous() };
        if (Match(TokenType.Nothing)) return new LiteralExpr { Value = null,  SourceToken = Previous() };

        // list literal
        if (Check(TokenType.LeftBracket))
        {
            Advance();
            var items = new List<Expression>();
            if (!Check(TokenType.RightBracket))
            {
                items.Add(ParseExpression());
                while (Match(TokenType.Comma)) items.Add(ParseExpression());
            }
            Consume(TokenType.RightBracket, "Expected ']' to close list literal.");
            return new ListLiteralExpr { Items = items, SourceToken = tok };
        }

        // grouped expression
        if (Check(TokenType.LeftParen))
        {
            Advance();
            var inner = ParseExpression();
            Consume(TokenType.RightParen, "Expected ')' after expression.");
            return inner;
        }

        // self reference
        if (Match(TokenType.Itself)) return new SelfExpr { SourceToken = Previous() };

        // new instance
        if (Match(TokenType.New))
        {
            var newTok = Previous();
            string bpName = ConsumeAnyName("Expected blueprint name after 'new'.").Lexeme;
            var args = Match(TokenType.With) ? ParseArgList() : Array.Empty<Expression>();
            return new NewObjectExpr { BlueprintName = bpName, Args = args, SourceToken = newTok };
        }

        // call function with args
        if (Match(TokenType.Call))
        {
            var callTok = Previous();
            var callee = ParseAccessChain();
            var args = Array.Empty<Expression>() as IReadOnlyList<Expression>;
            if (Match(TokenType.With)) args = ParseArgList();
            return new CallExpr { Callee = callee, Args = args, SourceToken = callTok };
        }

        // identifier (variable, call, access)
        if (CheckAnyName())
        {
            var identTok = Advance();
            var expr = (Expression)new VariableExpr { Name = identTok.Lexeme, SourceToken = identTok };

            // chained member access without dot: "person name" is NOT valid — dot required
            return expr;
        }

        // symbolic assignment inside expression context: should not appear, but handle gracefully
        Error(tok, $"Expected an expression, but got '{tok.Lexeme}'.");
        Advance();
        return new LiteralExpr { Value = null, SourceToken = tok };
    }

    // ─── Helper: parse access chain (a.b.c) for call targets ─────────────────

    private Expression ParseAccessChain()
    {
        var identTok = ConsumeAnyName("Expected function or variable name.");
        Expression expr = new VariableExpr { Name = identTok.Lexeme, SourceToken = identTok };
        while (Match(TokenType.Dot))
        {
            string member = ConsumeAnyName("Expected member name after '.'.").Lexeme;
            expr = new MemberAccessExpr { Object = expr, Member = member, SourceToken = Previous() };
        }
        return expr;
    }

    private IReadOnlyList<Expression> ParseArgList()
    {
        var args = new List<Expression>();
        if (IsAtNewlineOrEof() || Check(TokenType.RightParen)) return args;

        args.Add(ParseExpression());
        while (Match(TokenType.Comma) || (Check(TokenType.And) && !IsControlFlowNext()))
        {
            TryConsume(TokenType.And);
            if (IsAtNewlineOrEof()) break;
            args.Add(ParseExpression());
        }
        return args;
    }

    // ─── Block parsing ────────────────────────────────────────────────────────

    private BlockStmt ParseBlockUntil(params TokenType[] stopAt)
    {
        var stmts = new List<Statement>();
        SkipNewlines();
        while (!IsAtEnd())
        {
            if (stopAt.Contains(Current().Type)) break;
            try   { var s = ParseStatement(); if (s is not null) stmts.Add(s); }
            catch (ParseException ex) { foreach (var e in ex.Errors) _errors.Add(e); Synchronize(); }
            SkipNewlines();
        }
        return new BlockStmt { Statements = stmts, SourceToken = Current() };
    }

    // Consume 'end <keyword>' or just 'end'
    private void ConsumeEnd(string keyword)
    {
        Consume(TokenType.End, $"Expected 'end {keyword}'.");
        // optionally consume the matching keyword identifier
        if (Check(TokenType.Identifier) && string.Equals(Current().Lexeme, keyword, StringComparison.OrdinalIgnoreCase))
            Advance();
        else
        {
            // Try known token types
            switch (keyword)
            {
                case "if":       TryConsume(TokenType.If);       break;
                case "while":    TryConsume(TokenType.While);    break;
                case "repeat":   TryConsume(TokenType.Repeat);   break;
                case "for":      TryConsume(TokenType.For);      break;
                case "function": TryConsume(TokenType.Function); break;
                case "blueprint": TryConsume(TokenType.Blueprint); break;
            }
        }
    }

    // ─── Type name helpers ────────────────────────────────────────────────────

    private string? TryConsumeTypeHint()
    {
        if (Check(TokenType.TypeNumber) || Check(TokenType.TypeText) || Check(TokenType.TypeBool)
            || Check(TokenType.TypeList) || Check(TokenType.TypeObject) || Check(TokenType.TypeAny))
            return Advance().Lexeme;
        return null;
    }

    private string ConsumeTypeName()
    {
        if (Check(TokenType.Identifier)) return Advance().Lexeme;
        var tn = TryConsumeTypeHint();
        if (tn is not null) return tn;
        Error(Current(), "Expected a type name.");
        return "any";
    }

    // ─── Assign target ────────────────────────────────────────────────────────

    private Expression ParseAssignTarget()
    {
        var startTok = Current();
        Expression expr;

        // Allow 'itself' / 'self' as assignment target start (e.g. "set itself.x to 5")
        if (Check(TokenType.Itself))
        {
            Advance();
            expr = new SelfExpr { SourceToken = startTok };
        }
        else
        {
            var identTok = ConsumeAnyName("Expected variable name as assignment target.");
            expr = new VariableExpr { Name = identTok.Lexeme, SourceToken = identTok };
        }

        while (Match(TokenType.Dot))
        {
            string member = ConsumeAnyName("Expected member name after '.'.").Lexeme;
            expr = new MemberAccessExpr { Object = expr, Member = member, SourceToken = Previous() };
        }
        if (Check(TokenType.At))
        {
            var at = Advance(); TryConsume(TokenType.Index);
            var idx = ParseExpression();
            expr = new IndexExpr { Collection = expr, IndexValue = idx, SourceToken = at };
        }
        return expr;
    }

    // ─── Token navigation ─────────────────────────────────────────────────────

    private Token Current()  => _tokens[_pos];
    private Token Previous() => _tokens[_pos > 0 ? _pos - 1 : 0];
    private bool  IsAtEnd()  => Current().Type == TokenType.EOF;

    private bool Check(TokenType t) => !IsAtEnd() && Current().Type == t;

    private bool PeekIs(int offset, string lexeme)
    {
        int i = _pos + offset;
        while (i < _tokens.Count && _tokens[i].Type == TokenType.Newline) i++;
        return i < _tokens.Count && string.Equals(_tokens[i].Lexeme, lexeme, StringComparison.OrdinalIgnoreCase);
    }

    private Token Advance()
    {
        if (!IsAtEnd()) _pos++;
        return Previous();
    }

    private bool Match(TokenType t)
    {
        if (Check(t)) { Advance(); return true; }
        return false;
    }

    private Token Consume(TokenType t, string msg)
    {
        if (Check(t)) return Advance();
        Error(Current(), msg);
        return Current(); // recover
    }

    private bool TryConsume(TokenType t) => Match(t);
    private bool TryConsumeIdentifier(string lex)
    {
        if (Check(TokenType.Identifier) && string.Equals(Current().Lexeme, lex, StringComparison.OrdinalIgnoreCase))
        { Advance(); return true; }
        return false;
    }

    private void SkipNewlines() { while (Match(TokenType.Newline)) { } }

    private void ExpectNewlineOrEof()
    {
        SkipNewlines(); // newlines already consumed by prior logic sometimes
        // just tolerate — the English syntax is lenient
    }

    private bool IsAtNewlineOrEof() =>
        IsAtEnd() || Current().Type == TokenType.Newline;

    private bool IsControlFlowNext()
    {
        // Prevent 'and' from being consumed as logical operator
        // when it's part of a parameter list or blueprint field list
        if (!Check(TokenType.And)) return false;
        int save = _pos + 1;
        while (save < _tokens.Count && _tokens[save].Type == TokenType.Newline) save++;
        if (save >= _tokens.Count) return false;
        var next = _tokens[save].Type;
        return next is TokenType.If or TokenType.While or TokenType.Repeat
            or TokenType.For or TokenType.Return or TokenType.Break
            or TokenType.Continue or TokenType.Display or TokenType.End;
    }

    private bool IsParameterContext() => false; // refined per-context as needed

    private bool IsTimesInRepeat()
    {
        // 'times' after a numeric expr inside 'repeat' should not be treated as multiply
        // This is a heuristic — could be improved with a proper context flag
        return false;
    }

    private void Synchronize()
    {
        Advance();
        while (!IsAtEnd())
        {
            if (Previous().Type == TokenType.Newline) return;
            if (Current().Type is TokenType.Create or TokenType.Define or TokenType.Blueprint
                or TokenType.If or TokenType.While or TokenType.Repeat or TokenType.For
                or TokenType.Return or TokenType.Display or TokenType.EOF)
                return;
            Advance();
        }
    }

    private void Error(Token tok, string msg)
    {
        var err = new ParseError(msg, tok.Line, tok.Column, tok.File);
        _errors.Add(err);
        throw new ParseException(err);
    }
}

/// <summary>Result of parsing.</summary>
public sealed class ParseResult
{
    public ProgramNode               Program { get; }
    public IReadOnlyList<XeroxError> Errors  { get; }
    public bool HasErrors => Errors.Count > 0;

    public ParseResult(ProgramNode program, IReadOnlyList<XeroxError> errors)
    {
        Program = program;
        Errors  = errors;
    }
}