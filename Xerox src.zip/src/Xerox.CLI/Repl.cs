using Xerox.Core;
using Xerox.Core.Interpreter;

namespace Xerox.CLI;

/// <summary>
/// Interactive Read-Eval-Print Loop for Xerox.
/// Supports multi-line input, history, and coloured output.
/// </summary>
public sealed class XeroxRepl
{
    private readonly XeroxEngine _engine;
    private readonly List<string> _history = new();

    // Track multi-line open blocks
    private static readonly string[] BlockOpeners  = { "if ", "while ", "repeat ", "for each", "define ", "blueprint ", "build" };
    private static readonly string[] BlockClosers  = { "end" };

    public XeroxRepl(XeroxEngine engine) => _engine = engine;

    public void Run()
    {
        PrintBanner();

        var inputBuffer = new System.Text.StringBuilder();
        int depth = 0;

        while (true)
        {
            string prompt = depth > 0
                ? "".PadLeft(depth * 2 + 3, '.') + " "
                : ">>> ";

            Console.ForegroundColor = depth > 0 ? ConsoleColor.DarkCyan : ConsoleColor.Cyan;
            Console.Write(prompt);
            Console.ResetColor();

            string? line = Console.ReadLine();

            if (line is null) { Console.WriteLine(); break; }   // EOF (Ctrl+D / Ctrl+Z)

            // Special REPL commands
            if (depth == 0)
            {
                var cmd = line.Trim().ToLowerInvariant();
                if (cmd is "exit" or "quit" or ":q") break;
                if (cmd is "help" or ":help" or "?")   { PrintHelp();    continue; }
                if (cmd is "clear" or ":clear")         { Console.Clear(); PrintBanner(); continue; }
                if (cmd is "history" or ":history")     { PrintHistory();  continue; }
                if (cmd is "env" or ":env")             { PrintEnv();      continue; }
                if (cmd.StartsWith(":load "))
                {
                    var path = line.Trim().Substring(6).Trim();
                    LoadFile(path);
                    continue;
                }
            }

            // Track nesting depth
            string trimmed = line.TrimStart();
            if (BlockOpeners.Any(op => trimmed.StartsWith(op, StringComparison.OrdinalIgnoreCase)))
                depth++;
            if (BlockClosers.Any(cl => trimmed.StartsWith(cl, StringComparison.OrdinalIgnoreCase)) && depth > 0)
                depth--;

            inputBuffer.AppendLine(line);

            // Execute when block is closed or depth is 0 and line has content
            bool shouldExecute = depth == 0 && inputBuffer.Length > 0;

            if (shouldExecute)
            {
                string code = inputBuffer.ToString().Trim();
                inputBuffer.Clear();

                if (string.IsNullOrWhiteSpace(code)) continue;

                _history.Add(code);

                var (value, result) = _engine.Eval(code, "<repl>");

                if (!result.IsSuccess)
                {
                    foreach (var err in result.Errors)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Error.WriteLine($"  ✗ {err}");
                        Console.ResetColor();
                    }
                }
                else if (value is not null && !value.IsNothing)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"  = {value.ToDisplayString()}");
                    Console.ResetColor();
                }
            }
        }

        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine("\nGoodbye!");
        Console.ResetColor();
    }

    private void LoadFile(string path)
    {
        var result = _engine.RunFile(path);
        if (!result.IsSuccess)
        {
            foreach (var err in result.Errors)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Error.WriteLine($"  ✗ {err}");
                Console.ResetColor();
            }
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine($"  ✓ Loaded '{path}'");
            Console.ResetColor();
        }
    }

    private void PrintHistory()
    {
        if (_history.Count == 0) { Console.WriteLine("  (no history)"); return; }
        for (int i = 0; i < _history.Count; i++)
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write($"  {i + 1,3}  ");
            Console.ResetColor();
            var first = _history[i].Split('\n')[0];
            Console.WriteLine(first.Length > 70 ? first[..70] + "…" : first);
        }
    }

    private void PrintEnv()
    {
        var vars = _engine.Globals.GetAll()
                    .Where(kv => kv.Value.Kind != ValueKind.Callable)
                    .OrderBy(kv => kv.Key);
        foreach (var kv in vars)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"  {kv.Key,-20}");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write($"  {kv.Value.Kind,-10}");
            Console.ResetColor();
            Console.WriteLine($"  {kv.Value.ToDisplayString()}");
        }
    }

    private static void PrintBanner()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(@"
  ╔═══════════════════════════════════════╗
  ║   X E R O X   Language  v1.0.0       ║
  ║   English-style scripting language   ║
  ╚═══════════════════════════════════════╝");
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine("  Type 'help' for commands, 'exit' to quit.\n");
        Console.ResetColor();
    }

    private static void PrintHelp()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\n  REPL Commands");
        Console.ResetColor();
        Console.WriteLine("  help / ?         Show this help");
        Console.WriteLine("  exit / quit / :q Quit the REPL");
        Console.WriteLine("  clear / :clear   Clear the screen");
        Console.WriteLine("  history          Show input history");
        Console.WriteLine("  env              Show current variables");
        Console.WriteLine("  :load <path>     Load and run a Xerox file");
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\n  Quick Syntax Reference");
        Console.ResetColor();
        Console.WriteLine("  create number x with value 10");
        Console.WriteLine("  set x to x plus 1");
        Console.WriteLine("  display \"Hello, \" joined with name");
        Console.WriteLine("  define function add that takes a and b");
        Console.WriteLine("      give back a plus b");
        Console.WriteLine("  end function");
        Console.WriteLine("  if x is greater than 5 then");
        Console.WriteLine("      display x");
        Console.WriteLine("  end if\n");
    }
}
