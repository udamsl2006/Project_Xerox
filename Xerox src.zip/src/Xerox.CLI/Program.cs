using Xerox.Core;
using Xerox.CLI;

// ── Argument parsing ──────────────────────────────────────────────────────────

var engine  = new XeroxEngine();
bool verbose = false;

// Parse flags
var positional = new List<string>();
for (int i = 0; i < args.Length; i++)
{
    switch (args[i])
    {
        case "--verbose": case "-v":
            verbose = true;
            break;
        case "--version": case "-V":
            Console.WriteLine("Xerox Language Runtime v1.0.0");
            Console.WriteLine(".NET " + Environment.Version);
            return 0;
        case "--help": case "-h":
            PrintUsage();
            return 0;
        case "--eval": case "-e":
            if (i + 1 >= args.Length) { Console.Error.WriteLine("--eval requires an expression."); return 1; }
            i++;
            var evalResult = engine.Run(args[i], "<eval>");
            if (!evalResult.IsSuccess) { engine.PrintErrors(evalResult); return 1; }
            return 0;
        default:
            if (!args[i].StartsWith('-')) positional.Add(args[i]);
            else Console.Error.WriteLine($"Unknown flag: {args[i]}");
            break;
    }
}

engine.Verbose = verbose;

// ── Dispatch ──────────────────────────────────────────────────────────────────

if (positional.Count == 0)
{
    // Launch interactive REPL
    var repl = new XeroxRepl(engine);
    repl.Run();
    return 0;
}

// Run a source file
string filePath = positional[0];

// Pass remaining positional args as a 'args' list in the Xerox environment
if (positional.Count > 1)
{
    var argList = positional.Skip(1)
        .Select(Xerox.Core.Interpreter.XeValue.FromString)
        .ToList();
    engine.Globals.Define("args",
        Xerox.Core.Interpreter.XeValue.FromList(argList));
}
else
{
    engine.Globals.Define("args",
        Xerox.Core.Interpreter.XeValue.FromList(new List<Xerox.Core.Interpreter.XeValue>()));
}

var result = engine.RunFile(filePath);

if (!result.IsSuccess)
{
    string[] sourceLines = Array.Empty<string>();
    try { sourceLines = File.ReadAllLines(filePath); } catch { }
    engine.PrintErrors(result, sourceLines);
    return 1;
}

return 0;

// ── Helpers ───────────────────────────────────────────────────────────────────

static void PrintUsage()
{
    Console.WriteLine("""
        Xerox Language Runtime v1.0.0
        
        Usage:
          xerox                    Start the interactive REPL
          xerox <file.xe>          Run a Xerox source file
          xerox <file.xe> [args…]  Run a file with arguments
          xerox -e "expr"          Evaluate an expression directly
        
        Options:
          -h, --help               Show this help
          -V, --version            Show version info
          -v, --verbose            Enable verbose interpreter output
          -e, --eval <expr>        Evaluate expression and exit
        
        File extension: .xe or .xerox
        
        Example:
          xerox hello.xe
          xerox -e "display 2 plus 2"
        """);
}